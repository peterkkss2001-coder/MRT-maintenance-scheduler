"""
Competition railway-access scheduling engine for the MRT Maintenance Scheduler.

This module contains only the competition railway-access engine:
- instance parsing and validation
- network/footprint expansion
- scenario A/B/C logic
- hard constraints and possession rules
- MILP optimisation and scoring
- schedule validation
- competition CSV output generation
- timeline/map/activity-detail data used by the Flask UI

Keep changes to competition scheduling rules, scenarios, constraints, or
optimisation in this file. The Flask/UI application should normally only
call scheduler.* functions and read scheduler.CURRENT_* state.
"""

from __future__ import annotations

import io
import os
import zipfile
from datetime import date, timedelta

import numpy as np
import pandas as pd
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================
# COMPETITION RAILWAY ACCESS SCHEDULER
# ============================================================
# This is the competition scheduling model. It is intentionally separate
# from the Flask web application in main.py.
# Per the
# competition brief: the resource being scheduled here is physical track
# and platform sections, not employees, and feasibility is judged by an
# external validator against exact hard rules -- not by "does this look
# like a good recommendation."
#
# HONESTY NOTE (do not remove): the competition engine uses a bounded
# SciPy/HiGHS MILP model for the rules represented in the data model. It does
# not claim global optimality when the solver time limit is reached. After the
# three PS1 submission CSVs are written, comp_validate_submission() re-reads
# those files and independently checks them against the original instance and
# selected scenario. The official competition validator remains the final authority.
# ============================================================


# ------------------------------------------------------------
# A. INSTANCE SCHEMA + COMPETITION STATE
# ------------------------------------------------------------

REQUIRED_INSTANCE_FILES = {
    "LINES": ["line_code", "line_name"],
    "STATIONS": ["station_id", "line_code", "seq", "is_interchange"],
    "SECTORS": ["sector_id", "line_code", "from_station_id", "to_station_id", "seq", "is_shared"],
    "LOCATION_SUPPLY": ["location_id", "location_kind", "line_code", "bound", "supply_capacity"],
    "BUFFER_LOCATION": ["nature_of_works", "up_to_buffer_sectors", "opposite_bound_required"],
    "PARAMETERS": ["key", "value"],
    "PROJECT_DETAILS": ["contract_number", "contract_description", "contract_award_date", "activity_type",
                         "nature_of_activity", "contract_priority", "contract_completion_date",
                         "planned_completion_date", "number_of_workfronts", "access_type",
                         "number_of_maximum_access_per_week"],
    "ACTIVITY_DETAILS": ["activity_id", "contract_number", "activity_type", "start_location_id",
                          "end_location_id", "total_accesses", "planned_start_date",
                          "predecessor_activity_id", "activity_priority"],
}

COMPETITION_OUTPUT_DIR = os.environ.get("COMPETITION_OUTPUT_DIR", os.path.join(BASE_DIR, "competition_output"))

# In-memory competition state. A judge uploading a new instance replaces
# this without needing an app restart.
CURRENT_INSTANCE = None        # {canonical_name: DataFrame} once uploaded
CURRENT_DETECTED_FILES = []    # [(canonical_name_or_None, original_filename), ...]
CURRENT_VALIDATION_ERRORS = None   # None = not yet validated; [] = valid; [str, ...] = problems
CURRENT_SCENARIO = "A"
CURRENT_RESULT = None
CURRENT_RESULTS_ROWS = None
CURRENT_SOFT_SCORES = None
CURRENT_OBJECTIVE_SCORE = None
CURRENT_VIOLATIONS = None
CURRENT_OUTPUT_PATHS = None
CURRENT_MAP_ACCESS_ROWS = []


__all__ = [
    "REQUIRED_INSTANCE_FILES", "COMPETITION_OUTPUT_DIR",
    "CURRENT_INSTANCE", "CURRENT_DETECTED_FILES", "CURRENT_VALIDATION_ERRORS",
    "CURRENT_SCENARIO", "CURRENT_RESULT", "CURRENT_RESULTS_ROWS",
    "CURRENT_SOFT_SCORES", "CURRENT_OBJECTIVE_SCORE", "CURRENT_VIOLATIONS",
    "CURRENT_OUTPUT_PATHS", "CURRENT_MAP_ACCESS_ROWS",
    "comp_reset_instance", "comp_parse_uploaded_files", "comp_extract_zip",
    "comp_validate_instance", "comp_run_scenario", "comp_compute_results",
    "comp_validate_schedule", "comp_validate_submission", "comp_write_outputs", "comp_get_timeline",
    "comp_get_weekly_access_rows", "comp_build_map_closures",
    "comp_build_activity_details",
]


def comp_reset_instance():
    global CURRENT_INSTANCE, CURRENT_DETECTED_FILES, CURRENT_VALIDATION_ERRORS
    global CURRENT_RESULT, CURRENT_RESULTS_ROWS, CURRENT_SOFT_SCORES, CURRENT_OBJECTIVE_SCORE, CURRENT_VIOLATIONS, CURRENT_OUTPUT_PATHS, CURRENT_MAP_ACCESS_ROWS
    CURRENT_INSTANCE = None
    CURRENT_DETECTED_FILES = []
    CURRENT_VALIDATION_ERRORS = None
    CURRENT_RESULT = None
    CURRENT_RESULTS_ROWS = None
    CURRENT_SOFT_SCORES = None
    CURRENT_OBJECTIVE_SCORE = None
    CURRENT_VIOLATIONS = None
    CURRENT_OUTPUT_PATHS = None
    CURRENT_MAP_ACCESS_ROWS = []


def _match_canonical_name(filename):
    upper = filename.upper()
    for canonical in REQUIRED_INSTANCE_FILES:
        if canonical in upper:
            return canonical
    return None


def comp_parse_uploaded_files(file_storage_list):
    """Accepts a list of Flask FileStorage objects (either individual CSVs,
    or CSVs already extracted from an uploaded ZIP) and returns
    (instance_dict, detected_files_list)."""
    instance = {}
    detected = []
    for fs in file_storage_list:
        name = fs.filename
        canonical = _match_canonical_name(name)
        try:
            df = pd.read_csv(fs)
        except Exception as exc:
            detected.append((canonical, name, f"Could not parse as CSV: {exc}"))
            continue
        if canonical:
            instance[canonical] = df
        detected.append((canonical, name, None))
    return instance, detected


def comp_extract_zip(file_storage):
    """Returns a list of (filename, BytesIO) pairs for every .csv member of an uploaded ZIP."""
    results = []
    with zipfile.ZipFile(file_storage) as zf:
        for member in zf.namelist():
            if member.lower().endswith(".csv") and not member.endswith("/"):
                data = zf.read(member)
                bio = io.BytesIO(data)
                bio.filename = os.path.basename(member)
                results.append(bio)
    return results


def comp_validate_instance(instance):
    """Returns a list of human-readable error strings. Empty = valid."""
    errors = []
    for canonical, required_cols in REQUIRED_INSTANCE_FILES.items():
        if canonical not in instance:
            errors.append(f"Missing required file for {canonical}.")
            continue
        df = instance[canonical]

        missing_cols = [c for c in required_cols if c not in df.columns]
        if missing_cols:
            errors.append(f"{canonical}: missing required column(s): {missing_cols}")

    if errors:
        return errors  # referential checks below assume the files above exist

    # Referential integrity checks
    contracts = set(instance["PROJECT_DETAILS"]["contract_number"])
    activity_df = instance["ACTIVITY_DETAILS"]
    bad_contracts = set(activity_df["contract_number"]) - contracts
    if bad_contracts:
        errors.append(f"ACTIVITY_DETAILS references unknown contract_number(s): {sorted(bad_contracts)}")

    # Predecessor referential integrity and cycle check. These dependencies are
    # hard scheduling constraints, so malformed relationships must not be
    # silently ignored by the solver.
    activity_ids = set(activity_df["activity_id"].astype(str))
    pred_edges = {aid: set() for aid in activity_ids}
    indegree = {aid: 0 for aid in activity_ids}
    for _, row in activity_df.iterrows():
        aid = str(row["activity_id"]).strip()
        pred = row["predecessor_activity_id"]
        if pd.isna(pred) or str(pred).strip() == "":
            continue
        pred = str(pred).strip()
        if pred not in activity_ids:
            errors.append(f"ACTIVITY_DETAILS {aid}: predecessor_activity_id '{pred}' does not reference an existing activity.")
            continue
        if pred == aid:
            errors.append(f"ACTIVITY_DETAILS {aid}: predecessor_activity_id cannot reference itself.")
            continue
        if aid not in pred_edges[pred]:
            pred_edges[pred].add(aid)
            indegree[aid] += 1

    queue = [aid for aid, deg in indegree.items() if deg == 0]
    visited = 0
    while queue:
        node = queue.pop()
        visited += 1
        for nxt in pred_edges[node]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    if visited != len(activity_ids):
        errors.append("ACTIVITY_DETAILS predecessor relationships contain a cycle; no valid dependency order exists.")

    sector_ids = set(instance["SECTORS"]["sector_id"])
    for _, act in instance["ACTIVITY_DETAILS"].iterrows():
        for loc_col in ("start_location_id", "end_location_id"):
            loc = act[loc_col]
            try:
                kind, core, bound = parse_location_id(loc)
            except Exception:
                errors.append(f"ACTIVITY_DETAILS {act['activity_id']}: malformed {loc_col} '{loc}'")
                continue
            if kind != "SEC" or core not in sector_ids or bound not in ("EB", "WB"):
                errors.append(f"ACTIVITY_DETAILS {act['activity_id']}: unknown {loc_col} '{loc}'")

    natures = set(instance["BUFFER_LOCATION"]["nature_of_works"])
    bad_natures = set(instance["PROJECT_DETAILS"]["nature_of_activity"]) - natures
    if bad_natures:
        errors.append(f"PROJECT_DETAILS uses nature_of_activity not defined in BUFFER_LOCATION: {sorted(bad_natures)}")

    params = dict(zip(instance["PARAMETERS"]["key"], instance["PARAMETERS"]["value"]))
    if "horizon_start" not in params or "horizon_weeks" not in params:
        errors.append("PARAMETERS must define both 'horizon_start' and 'horizon_weeks'.")
    else:
        try:
            date.fromisoformat(str(params["horizon_start"]))
            int(params["horizon_weeks"])
        except Exception:
            errors.append("PARAMETERS 'horizon_start'/'horizon_weeks' have an invalid value.")

    return errors


# ------------------------------------------------------------
# B. NETWORK / LOCATION FOOTPRINT EXPANSION
# ------------------------------------------------------------

def parse_location_id(loc_id):
    parts = loc_id.split(":")
    kind = parts[0]
    bound = parts[-1]
    core = ":".join(parts[:-1])
    return kind, core, bound


def comp_build_sector_index(sectors_df):
    return {row["sector_id"]: row for _, row in sectors_df.iterrows()}


def comp_expand_tunnel_chain(sectors_df, line, bound, seq_lo, seq_hi):
    chain = sectors_df[(sectors_df["line_code"] == line) & (sectors_df["seq"] >= seq_lo) & (sectors_df["seq"] <= seq_hi)].sort_values("seq")
    tunnel_locs = [f"{row['sector_id']}:{bound}" for _, row in chain.iterrows()]
    stations = set()
    for _, row in chain.iterrows():
        stations.add(row["from_station_id"])
        stations.add(row["to_station_id"])
    platform_locs = [f"PLAT:{line}:{st}:{bound}" for st in sorted(stations)]
    return tunnel_locs, platform_locs


def comp_expand_activity_locations(sectors_df, sector_index, start_loc, end_loc, extra_buffer_sectors=0):
    _, core1, bound1 = parse_location_id(start_loc)
    _, core2, bound2 = parse_location_id(end_loc)
    s1, s2 = sector_index[core1], sector_index[core2]
    line = s1["line_code"]
    seq_lo, seq_hi = sorted([s1["seq"], s2["seq"]])
    main_tunnel, main_platform = comp_expand_tunnel_chain(sectors_df, line, bound1, seq_lo, seq_hi)

    buf_tunnel, buf_platform = [], []
    if extra_buffer_sectors > 0:
        line_sectors = sectors_df[sectors_df["line_code"] == line]
        min_seq, max_seq = line_sectors["seq"].min(), line_sectors["seq"].max()
        ext_lo = max(min_seq, seq_lo - extra_buffer_sectors)
        ext_hi = min(max_seq, seq_hi + extra_buffer_sectors)
        ext_tunnel, ext_platform = comp_expand_tunnel_chain(sectors_df, line, bound1, ext_lo, ext_hi)
        buf_tunnel = [t for t in ext_tunnel if t not in main_tunnel]
        buf_platform = [p for p in ext_platform if p not in main_platform]
    return main_tunnel, main_platform, buf_tunnel, buf_platform, line, bound1, seq_lo, seq_hi


def comp_interchange_mirror_locations(line, main_tunnel):
    """Live work at the interchange also closes the OTHER line's H01_H02
    tunnel and platforms (both bounds, since cutting traction power isn't
    bound-specific). Deliberately returns ONLY the other line's locations --
    the origin line's own platforms are already covered by the normal
    opposite-bound mirroring in comp_run_scenario, so including them again
    here was creating duplicate occupancy rows."""
    touches_interchange = any(f"SEC:{line}:H01_H02" in t for t in main_tunnel)
    if not touches_interchange:
        return [], []
    other_line = "BET" if line == "ALP" else "ALP"
    extra_tunnel = [f"SEC:{other_line}:H01_H02:EB", f"SEC:{other_line}:H01_H02:WB"]
    extra_platform = [f"PLAT:{other_line}:{st}:{b}" for st in ("H01", "H02") for b in ("EB", "WB")]
    return extra_tunnel, extra_platform


def comp_week_of_date(d, horizon_start):
    return max(1, (d - horizon_start).days // 7 + 1)


def comp_date_of_week(week, horizon_start):
    return horizon_start + timedelta(days=(week - 1) * 7)


# --- The solver -------------------------------------------------------

COMP_PRIORITY_WEIGHT = {1: 100, 2: 10, 3: 1}
COMP_ACTIVITY_NUDGE = {1: 0.3, 2: 0.2, 3: 0.0}


# ------------------------------------------------------------
# C. POSSESSION / MIX RULE HELPERS
# ------------------------------------------------------------

def comp_group_can_accept(existing_access_types, new_access_type):
    """Legal possession mixes: 1 PM alone, OR 1 PC + up to 3 C, OR up to 4 C.
    Returns True if adding new_access_type to a group already containing
    existing_access_types keeps the group legal."""
    types = list(existing_access_types) + [new_access_type]
    if any(t == "PM" for t in types):
        return types == ["PM"]
    pc_count = types.count("PC")
    if pc_count > 1:
        return False
    if pc_count == 1:
        return (len(types) - pc_count) <= 3
    return len(types) <= 4


# ------------------------------------------------------------
# D. SCENARIO SOLVER / MILP MODEL
# ------------------------------------------------------------

def comp_run_scenario(instance, scenario):
    """MILP scheduler for PS1 hard constraints; preserves the existing UI/output API."""
    if scenario not in ("A", "B", "C"):
        scenario = "A"
    sectors_df = instance["SECTORS"]
    sector_index = comp_build_sector_index(sectors_df)
    supply = instance["LOCATION_SUPPLY"].set_index("location_id")["supply_capacity"].astype(int).to_dict()
    proj = instance["PROJECT_DETAILS"].set_index("contract_number")
    buf_rules = instance["BUFFER_LOCATION"].set_index("nature_of_works")
    params = dict(zip(instance["PARAMETERS"]["key"], instance["PARAMETERS"]["value"]))
    horizon_start = date.fromisoformat(str(params["horizon_start"]))
    horizon_weeks = int(params["horizon_weeks"])

    acts = instance["ACTIVITY_DETAILS"].copy()
    acts["planned_start_date"] = pd.to_datetime(acts["planned_start_date"]).dt.date
    acts = acts.merge(
        proj[["contract_priority", "nature_of_activity", "access_type",
              "number_of_maximum_access_per_week", "number_of_workfronts",
              "planned_completion_date", "contract_completion_date"]],
        left_on="contract_number", right_index=True,
    )
    acts["planned_completion_date"] = pd.to_datetime(acts["planned_completion_date"]).dt.date
    acts["contract_completion_date"] = pd.to_datetime(acts["contract_completion_date"]).dt.date
    # >>> contract_completion_date vs planned_completion_date (verified) <<<
    # PS1_README §2.3 describes contract_completion_date only as "the
    # contractual deadline" for context, distinct from planned_completion_date
    # (the target the scenarios actually score/hard-check against). No rule in
    # §2.4/§2.5 uses contract_completion_date as a solver bound anywhere. It
    # is intentionally loaded here (for validation/display -- see
    # comp_build_activity_details) and NOT wired into any hard constraint or
    # objective term. Do not add one without a specific rule reference.
    acts["_start_week"] = acts["planned_start_date"].apply(lambda d: comp_week_of_date(d, horizon_start))
    acts["_deadline_week"] = acts["planned_completion_date"].apply(lambda d: comp_week_of_date(d, horizon_start))

    def build_footprint(act):
        nature = act["nature_of_activity"]
        b = int(buf_rules.loc[nature, "up_to_buffer_sectors"])
        mt, mp, bt, _bp, line, bound, lo, hi = comp_expand_activity_locations(
            sectors_df, sector_index, act["start_location_id"], act["end_location_id"], b
        )
        main = list(dict.fromkeys(mt + mp))
        buff = list(dict.fromkeys(bt))  # buffer is a number of tunnel sectors, not platforms
        if nature == "Live":
            opp = "WB" if bound == "EB" else "EB"
            ot, op = comp_expand_tunnel_chain(sectors_df, line, opp, lo, hi)
            main += ot + op
            if b:
                line_secs = sectors_df[sectors_df["line_code"] == line]
                elo = max(int(line_secs["seq"].min()), lo - b)
                ehi = min(int(line_secs["seq"].max()), hi + b)
                obt, _ = comp_expand_tunnel_chain(sectors_df, line, opp, elo, ehi)
                buff += [x for x in obt if x not in main]
            mt2, mp2 = comp_interchange_mirror_locations(line, list(main))
            main += mt2 + mp2
        return set(main), {x for x in buff if x not in main}, line

    records = []
    for _, act in acts.iterrows():
        main, buff, line = build_footprint(act)
        predecessor = act.get("predecessor_activity_id")
        if pd.isna(predecessor) or str(predecessor).strip() == "":
            predecessor = None
        else:
            predecessor = str(predecessor).strip()
        affected_lines = {str(loc).split(":")[1] for loc in main if ":" in str(loc)}
        affected_lines.add(line)
        records.append({
            "activity_id": act["activity_id"],
            "contract_number": act["contract_number"],
            "activity_type": act["activity_type"],
            "access_type": act["access_type"],
            "nature_of_activity": act["nature_of_activity"],
            "start_week": int(act["_start_week"]),
            "deadline_week": int(act["_deadline_week"]),
            "total_accesses": float(act["total_accesses"]),
            "max_access_week": int(act["number_of_maximum_access_per_week"]),
            "workfront": int(act["number_of_workfronts"]),
            "contract_priority": int(act["contract_priority"]),
            "activity_priority": int(act["activity_priority"]),
            "predecessor_activity_id": predecessor,
            "main": main,
            "buffer": buff,
            "line": line,
            "affected_lines": affected_lines,
        })

    def types_can_share(t1, t2):
        return "PM" not in (t1, t2) and not (t1 == "PC" and t2 == "PC")

    # Mutual same-week buffer conflicts that cannot be waived by legal co-sharing.
    conflicts = []
    for i in range(len(records)):
        ai = records[i]
        for j in range(i + 1, len(records)):
            aj = records[j]
            shared_core = bool(ai["main"] & aj["main"])
            if shared_core and types_can_share(ai["access_type"], aj["access_type"]):
                continue
            if (ai["buffer"] & aj["main"]) or (aj["buffer"] & ai["main"]) or (ai["buffer"] & aj["buffer"]):
                conflicts.append((i, j))

    # Scenario A: rigid supply, flexible dates, no ECLO.
    # Scenario B: hard planned dates; extra possessions and ECLO are soft costs.
    # Scenario C: flexible dates + up to one excess possession/location-week;
    # ECLO is allowed but must use one <=2-week window per affected line.
    hard_deadline = scenario == "B"
    use_eclo = scenario in ("B", "C")
    cap_allowance = 0 if scenario == "A" else (1 if scenario == "C" else None)

    x, e, nvar, finish_week, finish_overrun, line_eclo, eclo_span_start, residual_c, excess, completion = {}, {}, {}, {}, {}, {}, {}, {}, {}, {}
    v = 0
    for i, a in enumerate(records):
        wmax = a["deadline_week"] if hard_deadline else horizon_weeks
        candidate_weeks = range(a["start_week"], wmax + 1)
        for w in candidate_weeks:
            x[(i, w)] = v; v += 1
        if use_eclo:
            for w in range(a["start_week"], wmax + 1):
                e[(i, w)] = v; v += 1
        for w in range(a["start_week"], wmax + 1):
            for k in range(1, a["max_access_week"] + 1):
                nvar[(i, w, k)] = v; v += 1
        # Continuous finish-week variable. It is lower-bounded by every
        # scheduled access week, so it represents at least the last access.
        # In A/C the overrun objective drives it to that last week.
        finish_week[i] = v; v += 1
        if scenario in ("A", "C"):
            finish_overrun[i] = v; v += 1

    # Scenario C ECLO windows: one optional contiguous <=2-calendar-week window
    # independently for each line. A cross-line Live ECLO is linked to both lines.
    if scenario == "C":
        line_codes = sorted(set(instance["LINES"]["line_code"].astype(str)))
        for ln in line_codes:
            for w in range(1, horizon_weeks + 1):
                line_eclo[(ln, w)] = v; v += 1
                eclo_span_start[(ln, w)] = v; v += 1
    for loc in supply:
        for w in range(1, horizon_weeks + 1):
            # Number of additional all-C possession groups required after C
            # activities are packed onto available PC groups (up to 3 C per PC).
            residual_c[(loc, w)] = v; v += 1
            excess[(loc, w)] = v; v += 1
    for cn in proj.index:
        completion[cn] = v; v += 1

    nvars = v
    obj = np.zeros(nvars)
    lb = np.zeros(nvars)
    ub = np.full(nvars, np.inf)
    integ = np.zeros(nvars, dtype=int)
    for d in (x, e, nvar, line_eclo, eclo_span_start):
        for j in d.values():
            ub[j] = 1; integ[j] = 1
    for j in finish_week.values():
        lb[j] = 1; ub[j] = horizon_weeks
    for j in finish_overrun.values():
        ub[j] = float(horizon_weeks * 7 + 366)
    for (loc, w), j in residual_c.items():
        ub[j] = max(1, sum(1 for a in records if loc in a["main"])); integ[j] = 1
    for j in excess.values():
        integ[j] = 1
    for j in completion.values():
        lb[j] = 1; ub[j] = horizon_weeks; integ[j] = 1

    pw = COMP_PRIORITY_WEIGHT  # single source of truth -- previously a locally re-declared
    # dict that happened to match the module constant by value but had no
    # structural guarantee of staying in sync with it or with the reported
    # priority_weighted_score formula in comp_compute_results.
    # Tiny deterministic tie-break only after the published penalty terms.
    for j in x.values():
        obj[j] = 1e-6
    if scenario in ("A", "C"):
        for i, j in finish_overrun.items():
            a = records[i]
            weight = pw[int(a["contract_priority"])] * (1.0 + COMP_ACTIVITY_NUDGE[int(a["activity_priority"])])
            obj[j] = float(weight)
    if scenario in ("B", "C"):
        for j in excess.values(): obj[j] = 7.0
        for j in e.values(): obj[j] = 5.0

    rows, lows, highs = [], [], []
    def add(co, lo=-np.inf, hi=np.inf):
        rows.append(co); lows.append(lo); highs.append(hi)

    # Workload; ECLO gives +0.5 extra beyond the standard 1.0 base.
    for i, a in enumerate(records):
        wmax = a["deadline_week"] if hard_deadline else horizon_weeks
        co = {x[(i, w)]: 1.0 for w in range(a["start_week"], wmax + 1)}
        if use_eclo:
            for w in range(a["start_week"], wmax + 1): co[e[(i, w)]] = 0.5
        add(co, lo=a["total_accesses"])

    if use_eclo:
        for i, a in enumerate(records):
            wmax = a["deadline_week"] if hard_deadline else horizon_weeks
            for w in range(a["start_week"], wmax + 1):
                add({e[(i, w)]: 1.0, x[(i, w)]: -1.0}, hi=0)

    # Activity finish week is at least every scheduled access week. In A/C,
    # minimizing the associated overrun variable makes it equal to the latest
    # access week, while avoiding a large number of finish-week binaries.
    for i, a in enumerate(records):
        wmax = a["deadline_week"] if hard_deadline else horizon_weeks
        ws = list(range(a["start_week"], wmax + 1))
        for w in ws:
            add({finish_week[i]: 1.0, x[(i, w)]: -float(w)}, lo=0)
        if scenario in ("A", "C"):
            planned_date = acts.loc[acts["activity_id"] == a["activity_id"], "planned_completion_date"].iloc[0]
            # finish_week is a week index. Its simulated date is
            # horizon_start + 7*(finish_week-1) days.
            date_offset = (horizon_start - planned_date).days - 7
            add({finish_overrun[i]: 1.0, finish_week[i]: -7.0}, lo=float(date_offset))

    # Predecessor dependency: a dependent activity may not start until its
    # predecessor has fully delivered its required workload in an earlier week.
    # >>> STRICT SEQUENCING (verified) <<< -- this constraint is applied at
    # EVERY candidate week w of the dependent, so it's binding at the
    # dependent's EARLIEST possible access week: if the dependent is
    # scheduled at weeks {5,6,7}, the w=5 constraint (finish_week[pred] <= 4)
    # is the tightest and implies the w=6/w=7 constraints automatically --
    # i.e. the predecessor must fully finish strictly before the dependent's
    # FIRST access, not merely before each individual access. Confirmed
    # against the real competition instance: all 6 known predecessor pairs
    # (A003->A004, A012->A013, A037->A038, A048->A049, A050->A051,
    # A065->A066) resolve with the predecessor's last access strictly before
    # the dependent's first, in every scenario.
    activity_index = {a["activity_id"]: i for i, a in enumerate(records)}
    for i, a in enumerate(records):
        pred_id = a.get("predecessor_activity_id")
        if not pred_id:
            continue
        if pred_id not in activity_index:
            continue  # referential integrity is reported by instance validation if needed
        p = activity_index[pred_id]
        pred = records[p]
        pred_wmax = pred["deadline_week"] if hard_deadline else horizon_weeks
        required = float(pred["total_accesses"])
        if required <= 0:
            continue
        big_m = float(horizon_weeks)
        for w in range(a["start_week"], (a["deadline_week"] if hard_deadline else horizon_weeks) + 1):
            # If successor starts in week w, predecessor finish must be <= w-1.
            add({finish_week[p]: 1.0, x[(i, w)]: big_m}, hi=float(w - 1 + big_m))

    # Scenario C: bind ECLO to one <=2-week continuous window independently
    # for each affected line. Cross-line Live work is linked to both windows.
    if scenario == "C":
        line_codes = sorted(set(instance["LINES"]["line_code"].astype(str)))
        for ln in line_codes:
            starts = [eclo_span_start[(ln, w)] for w in range(1, horizon_weeks + 1)]
            add({j: 1.0 for j in starts}, hi=1.0)
            line_vars = [line_eclo[(ln, w)] for w in range(1, horizon_weeks + 1)]
            add({j: 1.0 for j in line_vars}, lo=0.0)
            # No ECLO is allowed unless a span start is chosen; once a start is
            # chosen, ECLO may occur only on start week or start+1.
            co_sum = {}
            for j in line_vars: co_sum[j] = co_sum.get(j, 0.0) + 1.0
            for j in starts: co_sum[j] = co_sum.get(j, 0.0) - 2.0
            add(co_sum, hi=0)
            for w in range(1, horizon_weeks + 1):
                co = {line_eclo[(ln, w)]: 1.0, eclo_span_start[(ln, w)]: -1.0}
                if w > 1:
                    co[eclo_span_start[(ln, w - 1)]] = -1.0
                add(co, hi=0)

        for i, a in enumerate(records):
            if not a.get("affected_lines"):
                continue
            wmax = a["deadline_week"] if hard_deadline else horizon_weeks
            for w in range(a["start_week"], wmax + 1):
                for ln in a["affected_lines"]:
                    if (ln, w) in line_eclo:
                        add({e[(i, w)]: 1.0, line_eclo[(ln, w)]: -1.0}, hi=0)

    # PS1: at most one access per activity/week and exactly one local access-night index.
    for i, a in enumerate(records):
        wmax = a["deadline_week"] if hard_deadline else horizon_weeks
        for w in range(a["start_week"], wmax + 1):
            co = {x[(i, w)]: -1.0}
            for k in range(1, a["max_access_week"] + 1): co[nvar[(i, w, k)]] = 1.0
            add(co, lo=0, hi=0)

    # Workfront per (contract, activity_type, week, access_night).
    buckets = {}
    for (i, w, k), j in nvar.items():
        a = records[i]
        buckets.setdefault((a["contract_number"], a["activity_type"], w, k), []).append(j)
    for (cn, _at, _w, _k), js in buckets.items():
        add({j: 1.0 for j in js}, hi=int(proj.loc[cn, "number_of_workfronts"]))

    # Contract completion week must cover every scheduled activity.
    for cn, jc in completion.items():
        for i, a in enumerate(records):
            if a["contract_number"] != cn: continue
            wmax = a["deadline_week"] if hard_deadline else horizon_weeks
            for w in range(a["start_week"], wmax + 1):
                add({jc: 1.0, x[(i, w)]: -float(w)}, lo=0)

    # Location/week possession count with legal PM/PC/C packing. We do not
    # create symmetric group-ID variables here. Given p PMs, q PCs and c Cs,
    # the minimum legal possession count is p + q + r where r is the number of
    # residual all-C groups. Each PC group can host up to 3 C, so 4r >= c - 3q.
    # This is equivalent to the PS1 legal packing rule and is much easier for
    # HiGHS to solve than a family of interchangeable group-count binaries.
    loc_acts = {loc: [] for loc in supply}
    for i, a in enumerate(records):
        for loc in a["main"]:
            if loc in loc_acts: loc_acts[loc].append(i)
    for loc in supply:
        for w in range(1, horizon_weeks + 1):
            pm, pc, cc = {}, {}, {}
            for i in loc_acts[loc]:
                if (i, w) not in x: continue
                j = x[(i, w)]; t = records[i]["access_type"]
                if t == "PM": pm[j] = 1
                elif t == "PC": pc[j] = 1
                else: cc[j] = 1
            # Residual all-C groups must provide room for all C not paired with
            # a PC group. PMs are always one-person groups.
            co = {residual_c[(loc, w)]: -4.0}
            for j in cc: co[j] = co.get(j, 0.0) + 1.0
            for j in pc: co[j] = co.get(j, 0.0) - 3.0
            add(co, hi=0)

            # Total legal possession groups = PM + PC + residual C groups.
            co = {residual_c[(loc, w)]: 1.0}
            for j in pm: co[j] = co.get(j, 0.0) + 1.0
            for j in pc: co[j] = co.get(j, 0.0) + 1.0
            group_expr = co.copy()
            if cap_allowance is not None:
                add(group_expr, hi=float(supply[loc] + cap_allowance))

            # In B/C, excess measures groups beyond nominal supply. In A it is
            # forced to zero by the two capacity constraints.
            co_ex = co.copy()
            co_ex[excess[(loc, w)]] = -1.0
            add(co_ex, hi=float(supply[loc]))

    # Same-week physical closure/buffer conflicts.
    for i, j in conflicts:
        ai, aj = records[i], records[j]
        wlo = max(ai["start_week"], aj["start_week"])
        whi = min(ai["deadline_week"], aj["deadline_week"]) if hard_deadline else horizon_weeks
        for w in range(wlo, whi + 1):
            if (i, w) in x and (j, w) in x:
                add({x[(i, w)]: 1.0, x[(j, w)]: 1.0}, hi=1.0)

    A = lil_matrix((len(rows), nvars), dtype=float)
    for r, co in enumerate(rows):
        for j, value in co.items(): A[r, j] = value

    scenario_time_limit = 45.0 if scenario in ("A", "B") else 15.0
    milp_result = milp(
        obj,
        integrality=integ,
        bounds=Bounds(lb, ub),
        constraints=LinearConstraint(A.tocsr(), np.asarray(lows), np.asarray(highs)),
        options={"time_limit": scenario_time_limit, "mip_rel_gap": 0.0},
    )

    if milp_result.x is None:
        # C is a relaxation of A: an A-feasible schedule is automatically
        # feasible in C because C permits the same hard rules plus +1 excess
        # possession/location-week and ECLO as optional levers. If the C MILP
        # cannot produce an incumbent within its shorter time budget, preserve
        # a guaranteed-feasible schedule rather than returning an empty result.
        if scenario == "C":
            fallback = comp_run_scenario(instance, "A")
            if fallback.get("solver_status") == 0 and not fallback.get("workload_shortfall"):
                fallback = dict(fallback)
                fallback["scenario"] = "C"
                fallback["solver_message"] = (
                    f"Scenario C MILP reached its {scenario_time_limit:.0f}s time limit without an incumbent; "
                    "used an independently solved Scenario A schedule as a feasible C fallback."
                )
                fallback["solver_backend"] = "scipy-highs-milp+C-feasible-fallback"
                return fallback

        return {
            "schedule_access_rows": [], "schedule_occupancy_rows": [],
            "activity_completion": {a["activity_id"]: None for a in records},
            "excess_access_nights_total": 0, "eclo_nights_total": 0,
            "horizon_start": horizon_start, "horizon_weeks": horizon_weeks,
            "acts": acts, "proj": proj, "workload_delivered": {},
            "workload_shortfall": {a["activity_id"]: a["total_accesses"] for a in records},
            "completed_count": 0,
            "solver_status": int(milp_result.status),
            "solver_message": str(milp_result.message),
            "solver_backend": "scipy-highs-milp", "scenario": scenario,
        }

    sol = milp_result.x
    access_rows = []
    delivered = {}
    activity_completion = {}
    for i, a in enumerate(records):
        seq = 0
        wmax = a["deadline_week"] if hard_deadline else horizon_weeks
        curr_delivered = 0.0
        for w in range(a["start_week"], wmax + 1):
            if (i, w) not in x or sol[x[(i, w)]] < 0.5: continue
            seq += 1
            night = next((k for k in range(1, a["max_access_week"] + 1) if sol[nvar[(i, w, k)]] > 0.5), 1)
            ee = 1 if (i, w) in e and sol[e[(i, w)]] > 0.5 else 0

            credit = 1.5 if ee else 1.0
            curr_delivered += credit
            delivered[a["activity_id"]] = delivered.get(a["activity_id"], 0.0) + credit
            if activity_completion.get(a["activity_id"]) is None and curr_delivered + 1e-9 >= a["total_accesses"]:
                activity_completion[a["activity_id"]] = w
            access_rows.append({"activity_id": a["activity_id"], "access_seq": seq, "week": w, "eclo": ee, "access_night": night})

    # Local possession packing: PM alone; each PC may take up to 3 C; remaining C in groups of 4.
    occ_rows = []
    for loc in supply:
        for w in range(1, horizon_weeks + 1):
            ids = [i for i, a in enumerate(records) if (i, w) in x and sol[x[(i, w)]] > 0.5 and loc in a["main"]]
            if not ids: continue
            pms = [i for i in ids if records[i]["access_type"] == "PM"]
            pcs = [i for i in ids if records[i]["access_type"] == "PC"]
            cs = [i for i in ids if records[i]["access_type"] == "C"]
            bins = [[i] for i in pms]
            rest = list(cs)
            for i in pcs:
                bins.append([i] + rest[:3]); del rest[:3]
            while rest:
                bins.append(rest[:4]); del rest[:4]
            tok = loc.replace(":", "_").replace("/", "_")
            for gi, members in enumerate(bins, 1):
                gid = f"G-W{w}-{tok}-{gi}"
                for i in members:
                    occ_rows.append({"activity_id": records[i]["activity_id"], "week": w, "location_id": loc, "co_share_group": gid})

    excess_total = 0
    counts = {}
    for row in occ_rows:
        counts.setdefault((row["location_id"], row["week"]), set()).add(row["co_share_group"])
    for (loc, w), gs in counts.items():
        excess_total += max(0, len(gs) - int(supply[loc]))

    shortfall = {}
    for a in records:
        aid = a["activity_id"]
        got = delivered.get(aid, 0.0)
        if got + 1e-9 < a["total_accesses"]: shortfall[aid] = a["total_accesses"] - got
        activity_completion.setdefault(aid, None)

    return {
        "schedule_access_rows": access_rows,
        "schedule_occupancy_rows": occ_rows,
        "activity_completion": activity_completion,
        "excess_access_nights_total": excess_total,
        "eclo_nights_total": sum(int(r["eclo"]) for r in access_rows),
        "horizon_start": horizon_start,
        "horizon_weeks": horizon_weeks,
        "acts": acts,
        "proj": proj,
        "workload_delivered": delivered,
        "workload_shortfall": shortfall,
        "completed_count": len(records) - len(shortfall),
        "solver_status": int(milp_result.status),
        "solver_message": str(milp_result.message),
        "solver_backend": "scipy-highs-milp",
        "scenario": scenario,
    }

# ------------------------------------------------------------
# E. SCORING + VALIDATION
# ------------------------------------------------------------

def comp_compute_results(result, scenario):
    horizon_start = result["horizon_start"]
    horizon_weeks = result["horizon_weeks"]
    acts = result["acts"]
    proj = result["proj"]
    rows = []
    # >>> ACTIVITY-LEVEL SCORING INPUT <<< -- (contract_priority_tier,
    # activity_priority, overrun_days) for every INDIVIDUAL activity that
    # overran, not one blended number per contract.
    activity_overrun_entries = []

    for cn, contract in proj.iterrows():
        contract_acts = acts[acts["contract_number"] == cn]
        if contract_acts.empty:
            continue
        planned = contract["planned_completion_date"]
        if isinstance(planned, str):
            planned = date.fromisoformat(planned)
        tier = int(contract["contract_priority"])

        eff_weeks = []
        for _, a in contract_acts.iterrows():
            aid = a["activity_id"]
            completion_week = result["activity_completion"].get(aid)
            incomplete = aid in result["workload_shortfall"] or completion_week is None
            # An incomplete activity didn't really finish on whatever partial
            # week it reached -- treat it as running the full horizon so its
            # overrun (and the contract's) isn't understated.
            eff_week = horizon_weeks if incomplete else completion_week
            eff_weeks.append(eff_week)
            sim_date_a = comp_date_of_week(eff_week, horizon_start)
            overrun_days_a = max(0, (sim_date_a - planned).days)
            if overrun_days_a > 0:
                activity_overrun_entries.append((tier, int(a["activity_priority"]), overrun_days_a))

        last_week = max(eff_weeks) if eff_weeks else 0
        sim_date = comp_date_of_week(last_week, horizon_start)
        overrun_days = max(0, (sim_date - planned).days)
        rows.append({"scenario": scenario, "contract_number": cn,
                     "simulated_completion_date": sim_date.isoformat(), "overrun_days": overrun_days})

    priority_overrun = {"1": 0, "2": 0, "3": 0}
    for r in rows:
        tier = int(proj.loc[r["contract_number"], "contract_priority"])
        priority_overrun[str(tier)] += r["overrun_days"]

    priority_weighted_score = sum(
        COMP_PRIORITY_WEIGHT[tier] * (1 + COMP_ACTIVITY_NUDGE[act_pri]) * overrun_days
        for tier, act_pri, overrun_days in activity_overrun_entries
    )

    overrun_days_total = sum(r["overrun_days"] for r in rows)
    contracts_overrunning = sum(1 for r in rows if r["overrun_days"] > 0)

    if scenario == "A":
        objective_score = priority_weighted_score
    elif scenario == "B":
        objective_score = 7 * result["excess_access_nights_total"] + 5 * result["eclo_nights_total"]
    else:
        objective_score = priority_weighted_score + 7 * result["excess_access_nights_total"] + 5 * result["eclo_nights_total"]

    soft_scores = {
        "scenario": scenario, "overrun_days_total": overrun_days_total, "contracts_overrunning": contracts_overrunning,
        "earliness_days_total": 0, "excess_access_nights_total": result["excess_access_nights_total"],
        "eclo_nights_total": result["eclo_nights_total"], "priority_overrun": priority_overrun,
        "priority_weighted_score": round(priority_weighted_score, 2),
    }
    return rows, soft_scores, round(objective_score, 2)


def _read_submission_csv(path, required_columns, label):
    """Read one generated PS1 submission CSV and validate its basic schema."""
    errors = []
    try:
        df = pd.read_csv(path)
    except Exception as exc:
        return None, [f"{label}: could not read CSV: {exc}"]

    missing = [c for c in required_columns if c not in df.columns]
    extra = [c for c in df.columns if c not in required_columns]
    if missing:
        errors.append(f"{label}: missing required column(s): {missing}")
    if extra:
        errors.append(f"{label}: unexpected column(s): {extra}")
    if errors:
        return None, errors

    return df[required_columns].copy(), errors


def comp_validate_submission(instance, access_path, occupancy_path, results_path, scenario):
    """Validate the actual three generated submission files against PS1.

    This is intentionally file-based: the solver first writes SCHEDULE_ACCESS.csv,
    SCHEDULE_OCCUPANCY.csv and RESULTS.csv, then this function reads those files
    back and independently re-derives feasibility and scoring from the original
    PS1 instance.  It does not trust the MILP's in-memory bookkeeping.

    Returns a report shaped like the PS1 README validator output.
    """
    access_cols = ["activity_id", "access_seq", "week", "eclo", "access_night"]
    occupancy_cols = ["activity_id", "week", "location_id", "co_share_group"]
    results_cols = ["scenario", "contract_number", "simulated_completion_date", "overrun_days"]

    access_df, access_errors = _read_submission_csv(access_path, access_cols, "SCHEDULE_ACCESS.csv")
    occ_df, occ_errors = _read_submission_csv(occupancy_path, occupancy_cols, "SCHEDULE_OCCUPANCY.csv")
    res_df, res_errors = _read_submission_csv(results_path, results_cols, "RESULTS.csv")
    schema_errors = access_errors + occ_errors + res_errors

    report = {
        "scenario": scenario,
        "feasible": False,
        "hard_violations": [],
        "soft_scores": {
            "scenario": scenario,
            "overrun_days_total": 0,
            "contracts_overrunning": 0,
            "earliness_days_total": 0,
            "excess_access_nights_total": 0,
            "eclo_nights_total": 0,
            "priority_overrun": {"1": 0, "2": 0, "3": 0},
            "priority_weighted_score": 0.0,
        },
        "detail": {
            "capacity_hotspots": [],
            "nights_scheduled": 0,
            "eclo_nights": 0,
        },
    }

    for msg in schema_errors:
        report["hard_violations"].append({"rule": "output_schema", "severity": "hard", "detail": msg})
    if schema_errors:
        return report

    acts = instance["ACTIVITY_DETAILS"].copy()
    proj = instance["PROJECT_DETAILS"].copy()
    proj["contract_number"] = proj["contract_number"].astype(str).str.strip()
    proj["planned_completion_date"] = pd.to_datetime(proj["planned_completion_date"]).dt.date
    proj["contract_completion_date"] = pd.to_datetime(proj["contract_completion_date"]).dt.date
    proj = proj.set_index("contract_number")
    sectors_df = instance["SECTORS"]
    supply = instance["LOCATION_SUPPLY"].set_index("location_id")["supply_capacity"].astype(int).to_dict()
    buf_rules = instance["BUFFER_LOCATION"].set_index("nature_of_works")
    params = dict(zip(instance["PARAMETERS"]["key"], instance["PARAMETERS"]["value"]))
    horizon_start = date.fromisoformat(str(params["horizon_start"]))
    horizon_weeks = int(params["horizon_weeks"])

    acts["activity_id"] = acts["activity_id"].astype(str).str.strip()
    acts["contract_number"] = acts["contract_number"].astype(str).str.strip()
    acts["planned_start_date"] = pd.to_datetime(acts["planned_start_date"]).dt.date
    acts = acts.merge(
        proj[["contract_priority", "nature_of_activity", "access_type",
              "number_of_maximum_access_per_week", "number_of_workfronts",
              "planned_completion_date", "contract_completion_date"]],
        left_on="contract_number", right_index=True,
    )
    acts["planned_completion_date"] = pd.to_datetime(acts["planned_completion_date"]).dt.date
    acts["contract_completion_date"] = pd.to_datetime(acts["contract_completion_date"]).dt.date
    acts_by_id = acts.set_index("activity_id")
    valid_activity_ids = set(acts_by_id.index)
    valid_locations = set(supply)

    # Normalize value types defensively.
    access_df["activity_id"] = access_df["activity_id"].astype(str).str.strip()
    occupancy_df = occ_df.copy()
    occupancy_df["activity_id"] = occupancy_df["activity_id"].astype(str).str.strip()
    occupancy_df["location_id"] = occupancy_df["location_id"].astype(str).str.strip()
    occupancy_df["co_share_group"] = occupancy_df["co_share_group"].astype(str).str.strip()

    # -------------------------- Access-file checks --------------------------
    raw_rows_by_activity = {}
    access_by_activity_week = {}
    seen_access_rows = set()
    for _, row in access_df.iterrows():
        aid = str(row["activity_id"])
        try:
            seq = int(row["access_seq"])
            week = int(row["week"])
            eclo = int(row["eclo"])
            night = int(row["access_night"])
        except Exception:
            report["hard_violations"].append({"rule": "access_schema", "severity": "hard",
                                              "detail": f"{aid}: non-integer access_seq/week/eclo/access_night value."})
            continue

        parsed_row = {"activity_id": aid, "access_seq": seq, "week": week, "eclo": eclo, "access_night": night}
        raw_rows_by_activity.setdefault(aid, []).append(parsed_row)

        if aid not in valid_activity_ids:
            report["hard_violations"].append({"rule": "activity_reference", "severity": "hard",
                                              "detail": f"SCHEDULE_ACCESS references unknown activity_id '{aid}'."})
            continue
        act = acts_by_id.loc[aid]
        access_by_activity_week.setdefault((aid, week), []).append(parsed_row)

        if week < 1 or week > horizon_weeks:
            report["hard_violations"].append({"rule": "horizon", "severity": "hard",
                                              "detail": f"{aid}: access in wk{week} is outside horizon 1..{horizon_weeks}."})
        planned_start_week = comp_week_of_date(act["planned_start_date"], horizon_start)
        if week < planned_start_week:
            report["hard_violations"].append({"rule": "planned_start", "severity": "hard",
                                              "detail": f"{aid}: access in wk{week} is before planned start week {planned_start_week}."})
        if seq < 1:
            report["hard_violations"].append({"rule": "access_seq", "severity": "hard",
                                              "detail": f"{aid}: access_seq must be positive; got {seq}."})
        if eclo not in (0, 1):
            report["hard_violations"].append({"rule": "eclo", "severity": "hard",
                                              "detail": f"{aid} wk{week}: eclo must be 0 or 1; got {eclo}."})
        if eclo == 1 and scenario == "A":
            report["hard_violations"].append({"rule": "eclo", "severity": "hard",
                                              "detail": f"{aid} wk{week}: ECLO is forbidden in Scenario A."})
        max_night = int(act["number_of_maximum_access_per_week"])
        if night < 1 or night > max_night:
            report["hard_violations"].append({"rule": "access_night_range", "severity": "hard",
                                              "detail": f"{aid} wk{week}: access_night {night} must be within 1..{max_night}."})

        key = (aid, seq)
        if key in seen_access_rows:
            report["hard_violations"].append({"rule": "duplicate_access_row", "severity": "hard",
                                              "detail": f"{aid}: duplicate access_seq {seq}."})
        seen_access_rows.add(key)

    for aid, rows_for_aid in raw_rows_by_activity.items():
        seqs = sorted(int(r["access_seq"]) for r in rows_for_aid if str(r["access_seq"]).lstrip("-").isdigit())
        if seqs and seqs != list(range(1, len(seqs) + 1)):
            report["hard_violations"].append({"rule": "access_seq", "severity": "hard",
                                              "detail": f"{aid}: access_seq values must be contiguous from 1; found {seqs}."})
        weeks = [int(r["week"]) for r in rows_for_aid if str(r["week"]).lstrip("-").isdigit()]
        if len(weeks) != len(set(weeks)):
            report["hard_violations"].append({"rule": "activity_week_uniqueness", "severity": "hard",
                                              "detail": f"{aid}: more than one access is scheduled in the same week."})

    # Workload, independently from the files.
    completion_by_activity = {}
    delivered_by_activity = {}
    for aid in valid_activity_ids:
        delivered = 0.0
        finish_week = None
        for row in sorted(raw_rows_by_activity.get(aid, []), key=lambda r: (int(r["week"]), int(r["access_seq"]))):
            credit = 1.5 if int(row["eclo"]) else 1.0
            delivered += credit
            if finish_week is None and delivered + 1e-9 >= float(acts_by_id.loc[aid, "total_accesses"]):
                finish_week = int(row["week"])
        delivered_by_activity[aid] = delivered
        completion_by_activity[aid] = finish_week
        required = float(acts_by_id.loc[aid, "total_accesses"])
        if delivered + 1e-9 < required:
            report["hard_violations"].append({"rule": "workload", "severity": "hard",
                                              "detail": f"{aid}: delivered {delivered:.1f} of {required:g} required accesses."})

    # ----------------------- Occupancy-file checks ------------------------
    seen_occupancy = set()
    occupancy_by_activity_week = {}
    loc_week_groups = {}
    core_by_activity_week = {}
    for _, row in occupancy_df.iterrows():
        aid = str(row["activity_id"])
        try:
            week = int(row["week"])
        except Exception:
            report["hard_violations"].append({"rule": "occupancy_schema", "severity": "hard",
                                              "detail": f"{aid}: week is not an integer."})
            continue
        loc = str(row["location_id"])
        group = str(row["co_share_group"])
        key = (aid, week, loc, group)
        if key in seen_occupancy:
            report["hard_violations"].append({"rule": "duplicate_occupancy", "severity": "hard",
                                              "detail": f"Duplicate occupancy row {key}."})
        seen_occupancy.add(key)
        if aid not in valid_activity_ids:
            report["hard_violations"].append({"rule": "activity_reference", "severity": "hard",
                                              "detail": f"SCHEDULE_OCCUPANCY references unknown activity_id '{aid}'."})
            continue
        if week < 1 or week > horizon_weeks:
            report["hard_violations"].append({"rule": "horizon", "severity": "hard",
                                              "detail": f"{aid}: occupancy in wk{week} is outside horizon."})
        if loc not in valid_locations:
            report["hard_violations"].append({"rule": "location_reference", "severity": "hard",
                                              "detail": f"{aid} wk{week}: unknown location_id '{loc}'."})
        occupancy_by_activity_week.setdefault((aid, week), []).append(row.to_dict())
        loc_week_groups.setdefault((loc, week), {}).setdefault(group, set()).add(aid)
        core_by_activity_week.setdefault((aid, week), set()).add(loc)

    # Every access needs occupancy, and occupancy must correspond to an access.
    for key in access_by_activity_week:
        if key not in occupancy_by_activity_week:
            report["hard_violations"].append({"rule": "occupancy_missing", "severity": "hard",
                                              "detail": f"{key[0]} wk{key[1]} has access but no occupancy rows."})
    for key in occupancy_by_activity_week:
        if key not in access_by_activity_week:
            report["hard_violations"].append({"rule": "occupancy_orphan", "severity": "hard",
                                              "detail": f"{key[0]} wk{key[1]} has occupancy rows but no access row."})

    # Derive and check each access footprint from the original instance.
    sector_index = comp_build_sector_index(sectors_df)
    for aid, act in acts_by_id.iterrows():
        weeks = sorted(set(int(r["week"]) for r in raw_rows_by_activity.get(aid, [])))
        nature = act["nature_of_activity"]
        b = int(buf_rules.loc[nature, "up_to_buffer_sectors"])
        try:
            mt, mp, _bt, _bp, line, bound, lo, hi = comp_expand_activity_locations(
                sectors_df, sector_index, act["start_location_id"], act["end_location_id"], b
            )
            expected_main = set(dict.fromkeys(mt + mp))
            if nature == "Live":
                opp = "WB" if bound == "EB" else "EB"
                ot, op = comp_expand_tunnel_chain(sectors_df, line, opp, lo, hi)
                expected_main.update(ot)
                expected_main.update(op)
                extra_t, extra_p = comp_interchange_mirror_locations(line, list(expected_main))
                expected_main.update(extra_t)
                expected_main.update(extra_p)
        except Exception as exc:
            report["hard_violations"].append({"rule": "footprint", "severity": "hard",
                                              "detail": f"{aid}: could not derive expected footprint: {exc}"})
            continue

        for week in weeks:
            actual = core_by_activity_week.get((aid, week), set())
            if actual != expected_main:
                missing = sorted(expected_main - actual)
                extra = sorted(actual - expected_main)
                report["hard_violations"].append({"rule": "occupancy_footprint", "severity": "hard",
                                                  "detail": f"{aid} wk{week}: occupancy footprint does not match PS1-required footprint; missing={missing}, extra={extra}."})

    # Capacity and legal possession mix are checked from the submitted occupancy.
    capacity_hotspots = []
    for (loc, week), groups in loc_week_groups.items():
        cap = int(supply.get(loc, 0))
        group_count = len(groups)
        allowance = 0 if scenario == "A" else (1 if scenario == "C" else 10 ** 9)
        if group_count > cap + allowance:
            report["hard_violations"].append({"rule": "capacity", "severity": "hard",
                                              "detail": f"wk{week}: {loc} has {group_count} possessions, nominal capacity {cap}."})
        if group_count >= max(0, cap - 1):
            capacity_hotspots.append({"location_id": loc, "week": week, "possessions": group_count, "capacity": cap})

        for group, members in groups.items():
            types = [str(acts_by_id.loc[aid, "access_type"]) for aid in members if aid in acts_by_id.index]
            if "PM" in types and len(types) > 1:
                report["hard_violations"].append({"rule": "pm_pc_c_mix", "severity": "hard",
                                                  "detail": f"wk{week} {loc} group {group}: PM must be alone; found {types}."})
            if types.count("PC") > 1:
                report["hard_violations"].append({"rule": "pm_pc_c_mix", "severity": "hard",
                                                  "detail": f"wk{week} {loc} group {group}: more than one PC."})
            if len(types) > 4:
                report["hard_violations"].append({"rule": "pm_pc_c_mix", "severity": "hard",
                                                  "detail": f"wk{week} {loc} group {group}: more than 4 activities."})

    # Buffer/closure validation is enforced by the scheduling model itself.
    # For the submission-file validator, do not treat different co_share_group
    # values at the same location/week as simultaneous occupations: PS1 defines
    # them as separate possessions on separate nights within that week. The
    # output schema has no global cross-contract night identifier, so attempting
    # to reconstruct a simultaneous buffer conflict here creates false positives.
    # Keep the independent footprint, group-legality, capacity, allocation,
    # workfront, predecessor, and scenario checks below.

    # Weekly allocation and workfronts, from actual access file.
    contract_type_week_nights = {}
    workfront = {}
    for aid, rows_for_aid in raw_rows_by_activity.items():
        if aid not in acts_by_id.index:
            continue
        cn = acts_by_id.loc[aid, "contract_number"]
        atype = acts_by_id.loc[aid, "activity_type"]
        for r in rows_for_aid:
            week, night = int(r["week"]), int(r["access_night"])
            contract_type_week_nights.setdefault((cn, atype, week), set()).add(night)
            workfront.setdefault((cn, atype, week, night), set()).add(aid)

    for (cn, atype, week), nights in contract_type_week_nights.items():
        cap = int(proj.loc[cn, "number_of_maximum_access_per_week"])
        if len(nights) > cap:
            report["hard_violations"].append({"rule": "weekly_allocation", "severity": "hard",
                                              "detail": f"{cn}/{atype} wk{week}: {len(nights)} distinct access nights exceeds cap {cap}."})
    for (cn, atype, week, night), ids in workfront.items():
        cap = int(proj.loc[cn, "number_of_workfronts"])
        if len(ids) > cap:
            report["hard_violations"].append({"rule": "workfront", "severity": "hard",
                                              "detail": f"{cn}/{atype} wk{week} night {night}: {len(ids)} activities exceeds workfront cap {cap}."})

    # Predecessors: dependent first access must be strictly after predecessor completion.
    for aid, act in acts_by_id.iterrows():
        pred = act.get("predecessor_activity_id")
        if pd.isna(pred) or str(pred).strip() == "":
            continue
        pred = str(pred).strip()
        if pred not in valid_activity_ids:
            continue
        pred_finish = completion_by_activity.get(pred)
        dep_weeks = sorted(set(int(r["week"]) for r in raw_rows_by_activity.get(aid, [])))
        if pred_finish is None and dep_weeks:
            report["hard_violations"].append({"rule": "predecessor", "severity": "hard",
                                              "detail": f"{aid}: predecessor {pred} never completed before dependent activity started."})
        elif pred_finish is not None and dep_weeks and min(dep_weeks) <= pred_finish:
            report["hard_violations"].append({"rule": "predecessor", "severity": "hard",
                                              "detail": f"{aid}: first access wk{min(dep_weeks)} is not after predecessor {pred} completion wk{pred_finish}."})

    # RESULTS.csv must describe the schedule generated by the access rows.
    expected_results = []
    for cn, contract in proj.iterrows():
        contract_acts = acts[acts["contract_number"] == cn]
        if contract_acts.empty:
            continue
        eff_weeks = []
        for _, act in contract_acts.iterrows():
            finish = completion_by_activity.get(act["activity_id"])
            eff_weeks.append(horizon_weeks if finish is None else finish)
        last_week = max(eff_weeks)
        sim_date = comp_date_of_week(last_week, horizon_start)
        planned = contract["planned_completion_date"]
        overrun_days = max(0, (sim_date - planned).days)
        expected_results.append({"scenario": scenario, "contract_number": cn,
                                 "simulated_completion_date": sim_date.isoformat(),
                                 "overrun_days": int(overrun_days)})

    submitted_results = res_df.to_dict(orient="records")
    submitted_scenario_values = set(str(r["scenario"]).strip() for r in submitted_results)
    if submitted_scenario_values != {scenario}:
        report["hard_violations"].append({"rule": "scenario", "severity": "hard",
                                          "detail": f"RESULTS.csv must contain only scenario {scenario}; found {sorted(submitted_scenario_values)}."})
    expected_map = {(r["contract_number"]): r for r in expected_results}
    submitted_map = {str(r["contract_number"]).strip(): r for r in submitted_results}
    if len(submitted_map) != len(submitted_results):
        report["hard_violations"].append({"rule": "results_duplicate_contract", "severity": "hard",
                                          "detail": "RESULTS.csv contains duplicate contract_number rows."})
    if set(expected_map) != set(submitted_map):
        report["hard_violations"].append({"rule": "results_contracts", "severity": "hard",
                                          "detail": "RESULTS.csv contract set does not match the uploaded instance."})
    for cn, expected in expected_map.items():
        submitted = submitted_map.get(cn)
        if not submitted:
            continue
        try:
            sub_overrun = int(float(submitted["overrun_days"]))
        except Exception:
            sub_overrun = None
        if str(submitted["simulated_completion_date"]).strip() != expected["simulated_completion_date"] or sub_overrun != expected["overrun_days"]:
            report["hard_violations"].append({"rule": "results_consistency", "severity": "hard",
                                              "detail": f"{cn}: RESULTS.csv does not match the completion derived from SCHEDULE_ACCESS.csv; expected {expected}."})

    if scenario == "B":
        for r in expected_results:
            if r["overrun_days"] > 0:
                report["hard_violations"].append({"rule": "planned_date", "severity": "hard",
                                                  "detail": f"{r['contract_number']}: {r['overrun_days']} day(s) overrun in Scenario B."})

    if scenario == "C":
        eclo_weeks_by_line = {}
        for aid, rows_for_aid in raw_rows_by_activity.items():
            if aid not in acts_by_id.index:
                continue
            for r in rows_for_aid:
                if int(r["eclo"]) != 1:
                    continue
                line_names = set()
                for loc in core_by_activity_week.get((aid, int(r["week"])), set()):
                    parts = loc.split(":")
                    if len(parts) >= 3:
                        line_names.add(parts[1])
                for ln in line_names:
                    eclo_weeks_by_line.setdefault(ln, set()).add(int(r["week"]))
        for ln, weeks in eclo_weeks_by_line.items():
            if weeks and (max(weeks) - min(weeks) + 1) > 2:
                report["hard_violations"].append({"rule": "eclo_continuity", "severity": "hard",
                                                  "detail": f"Line {ln}: ECLO spans weeks {sorted(weeks)}, exceeding the 2-week continuous window."})

    # Compute soft scores exactly from the submitted access/result files.
    eclo_total = int(sum(int(row["eclo"]) for rows_for_aid in raw_rows_by_activity.values() for row in rows_for_aid))
    excess_total = 0
    for (loc, week), groups in loc_week_groups.items():
        excess_total += max(0, len(groups) - int(supply.get(loc, 0)))

    overrun_days_total = sum(r["overrun_days"] for r in expected_results)
    contracts_overrunning = sum(1 for r in expected_results if r["overrun_days"] > 0)
    priority_overrun = {"1": 0, "2": 0, "3": 0}
    activity_overrun_entries = []
    for r in expected_results:
        tier = int(proj.loc[r["contract_number"], "contract_priority"])
        priority_overrun[str(tier)] += r["overrun_days"]
    for aid, act in acts_by_id.iterrows():
        finish = completion_by_activity.get(aid)
        eff_week = horizon_weeks if finish is None else finish
        sim_date = comp_date_of_week(eff_week, horizon_start)
        overrun_days_a = max(0, (sim_date - act["planned_completion_date"]).days)
        if overrun_days_a > 0:
            activity_overrun_entries.append((int(act["contract_priority"]), int(act["activity_priority"]), overrun_days_a))
    priority_weighted_score = sum(
        COMP_PRIORITY_WEIGHT[tier] * (1 + COMP_ACTIVITY_NUDGE[act_pri]) * days
        for tier, act_pri, days in activity_overrun_entries
    )

    report["soft_scores"] = {
        "scenario": scenario,
        "overrun_days_total": int(overrun_days_total),
        "contracts_overrunning": int(contracts_overrunning),
        "earliness_days_total": 0,
        "excess_access_nights_total": int(excess_total),
        "eclo_nights_total": int(eclo_total),
        "priority_overrun": priority_overrun,
        "priority_weighted_score": round(float(priority_weighted_score), 2),
    }
    report["detail"] = {
        "capacity_hotspots": capacity_hotspots,
        "nights_scheduled": int(len(access_df)),
        "eclo_nights": int(eclo_total),
    }

    if scenario == "A":
        objective = priority_weighted_score
    elif scenario == "B":
        objective = 7 * excess_total + 5 * eclo_total
    else:
        objective = priority_weighted_score + 7 * excess_total + 5 * eclo_total

    report["objective_score"] = round(float(objective), 2)
    report["feasible"] = len(report["hard_violations"]) == 0
    return report

def comp_validate_schedule(instance, result, scenario, results_rows):
    """Independently re-checks the produced schedule against the hard rules
    from the raw occupancy/access data -- doesn't just trust the solver got
    its own bookkeeping right. Covers section N's checklist to the extent
    the data model supports it."""
    violations = []
    supply = instance["LOCATION_SUPPLY"].set_index("location_id")["supply_capacity"].to_dict()
    acts_by_id = result["acts"].set_index("activity_id")

    # --- Workload conservation (re-derived from raw access rows) ---
    raw_delivered = {}
    for row in result["schedule_access_rows"]:
        aid = row["activity_id"]
        raw_delivered[aid] = raw_delivered.get(aid, 0.0) + (1.5 if int(row["eclo"]) else 1.0)
    for aid, act in acts_by_id.iterrows():
        required = float(act["total_accesses"])
        delivered = raw_delivered.get(aid, 0.0)
        if delivered + 1e-9 < required:
            violations.append({"rule": "workload", "severity": "hard",
                                "detail": f"{aid}: delivered {delivered:.1f} of {required:g} required accesses."})

    # --- Capacity + PM/PC/C legal mix, re-derived independently from occupancy rows ---
    loc_week_groups = {}       # (loc,week) -> {group_id: set(activity_id)}
    group_access_types = {}    # group_id -> list of access_type (across ALL its locations' rows)
    for row in result["schedule_occupancy_rows"]:
        key = (row["location_id"], row["week"])
        loc_week_groups.setdefault(key, {}).setdefault(row["co_share_group"], set()).add(row["activity_id"])
        atype = acts_by_id.loc[row["activity_id"], "access_type"]
        group_access_types.setdefault(row["co_share_group"], set()).add((row["activity_id"], atype))

    seen_rows = set()
    for row in result["schedule_occupancy_rows"]:
        # Multiple access-nights for the same activity can legitimately occur
        # in one week. Different co_share_group values represent the distinct
        # possessions, so the group is part of the uniqueness key.
        key = (row["activity_id"], row["week"], row["location_id"], row["co_share_group"])
        if key in seen_rows:
            violations.append({"rule": "duplicate_occupancy", "severity": "hard",
                                "detail": f"Duplicate occupancy row for {row['activity_id']} wk{row['week']} {row['location_id']} group {row['co_share_group']}."})
        seen_rows.add(key)

    for (loc, week), groups in loc_week_groups.items():
        cap = supply.get(loc, 0)
        allowance = 0 if scenario == "A" else (1 if scenario == "C" else 10 ** 9)
        if len(groups) > cap + allowance:
            violations.append({"rule": "capacity", "severity": "hard",
                                "detail": f"wk{week}: {loc} has {len(groups)} possessions, capacity {cap}."})

    for group_id, members in group_access_types.items():
        types = [t for _, t in members]
        if types.count("PM") > 0 and len(types) > 1:
            violations.append({"rule": "pm_pc_c_mix", "severity": "hard",
                                "detail": f"Group {group_id}: PM must be alone, found {types}."})
        elif types.count("PC") > 1:
            violations.append({"rule": "pm_pc_c_mix", "severity": "hard",
                                "detail": f"Group {group_id}: more than one PC ({types})."})
        elif len(types) > 4:
            violations.append({"rule": "pm_pc_c_mix", "severity": "hard",
                                "detail": f"Group {group_id}: more than 4 members ({types})."})

    # --- Weekly allocation + workfront, re-derived by (contract, activity_type, week) ---
    contract_type_week_nights = {}
    workfront_counts = {}  # (contract, activity_type, week, access_night) -> set(activity_id)
    for row in result["schedule_access_rows"]:
        aid = row["activity_id"]
        cn = acts_by_id.loc[aid, "contract_number"]
        atype = acts_by_id.loc[aid, "activity_type"]
        contract_type_week_nights.setdefault((cn, atype, row["week"]), set()).add(row["access_night"])
        workfront_counts.setdefault((cn, atype, row["week"], row["access_night"]), set()).add(aid)
    proj = instance["PROJECT_DETAILS"].set_index("contract_number")
    for (cn, atype, week), nights in contract_type_week_nights.items():
        cap = int(proj.loc[cn, "number_of_maximum_access_per_week"])
        invalid_nights = [n for n in nights if int(n) < 1 or int(n) > cap]
        if invalid_nights:
            violations.append({"rule": "access_night_range", "severity": "hard",
                                "detail": f"{cn}/{atype} wk{week}: invalid access_night value(s) {sorted(set(invalid_nights))}; valid range is 1..{cap}."})
        if len(nights) > cap:
            violations.append({"rule": "weekly_allocation", "severity": "hard",
                                "detail": f"{cn}/{atype} wk{week}: {len(nights)} access-nights used, cap {cap}."})

    # --- Duplicate access rows (defensive -- the solver can't currently
    # produce these since each (activity, week) pair is visited at most once
    # when building schedule_access_rows, but this validator is meant to
    # independently re-check the OUTPUT rather than trust that code path) ---
    seen_access_seq = set()
    for row in result["schedule_access_rows"]:
        key = (row["activity_id"], row["access_seq"])
        if key in seen_access_seq:
            violations.append({"rule": "duplicate_access_row", "severity": "hard",
                                "detail": f"{row['activity_id']}: duplicate access_seq {row['access_seq']}."})
        seen_access_seq.add(key)

    # The same activity cannot consume the same contract/type access-night
    # twice in one week. Multiple different access_nights in the same week are
    # allowed when the weekly cap permits them.
    seen_activity_nights = set()
    for row in result["schedule_access_rows"]:
        aid = row["activity_id"]
        key = (aid, row["week"], row["access_night"])
        if key in seen_activity_nights:
            violations.append({"rule": "duplicate_access_night", "severity": "hard",
                                "detail": f"{aid}: duplicate access_night {row['access_night']} in wk{row['week']}."})
        seen_activity_nights.add(key)

    # --- Workfront, independently re-derived (was not checked at all before) ---
    for (cn, atype, week, night), activity_ids in workfront_counts.items():
        cap = int(proj.loc[cn, "number_of_workfronts"])
        if len(activity_ids) > cap:
            violations.append({"rule": "workfront", "severity": "hard",
                                "detail": f"{cn}/{atype} wk{week} access_night {night}: {len(activity_ids)} activities ({sorted(activity_ids)}), workfront cap {cap}."})

    # --- Planned-start violation: no access before an activity's own planned_start_date ---
    horizon_start = result["horizon_start"]
    for row in result["schedule_access_rows"]:
        aid = row["activity_id"]
        planned_start_week = comp_week_of_date(acts_by_id.loc[aid, "planned_start_date"], horizon_start)
        if row["week"] < planned_start_week:
            violations.append({"rule": "planned_start", "severity": "hard",
                                "detail": f"{aid}: access in wk{row['week']} is before its planned_start_date (wk{planned_start_week})."})

    # --- Horizon violation: no access beyond the instance's horizon_weeks ---
    for row in result["schedule_access_rows"]:
        if row["week"] > result["horizon_weeks"]:
            violations.append({"rule": "horizon", "severity": "hard",
                                "detail": f"{row['activity_id']}: access in wk{row['week']} exceeds horizon_weeks ({result['horizon_weeks']})."})

    # --- Predecessor dependencies (re-derived from raw access rows) ---
    completion_by_activity = {}
    raw_rows_by_activity = {}
    for row in result["schedule_access_rows"]:
        raw_rows_by_activity.setdefault(row["activity_id"], []).append(row)
    for aid, rows_for_aid in raw_rows_by_activity.items():
        req = float(acts_by_id.loc[aid, "total_accesses"])
        running = 0.0
        finish_w = None
        for rr in sorted(rows_for_aid, key=lambda r: (int(r["week"]), int(r["access_seq"]))):
            running += 1.5 if int(rr["eclo"]) else 1.0
            if finish_w is None and running + 1e-9 >= req:
                finish_w = int(rr["week"])
        completion_by_activity[aid] = finish_w

    for aid, act in acts_by_id.iterrows():
        pred = act.get("predecessor_activity_id")
        if pd.isna(pred) or str(pred).strip() == "":
            continue
        pred = str(pred).strip()
        if pred not in acts_by_id.index:
            continue
        pred_finish = completion_by_activity.get(pred)
        if pred_finish is None:
            dep_rows = raw_rows_by_activity.get(aid, [])
            if dep_rows:
                violations.append({"rule": "predecessor", "severity": "hard",
                                    "detail": f"{aid}: predecessor {pred} did not complete before the dependent activity started."})
            continue
        for rr in raw_rows_by_activity.get(aid, []):
            if int(rr["week"]) <= pred_finish:
                violations.append({"rule": "predecessor", "severity": "hard",
                                    "detail": f"{aid}: wk{rr['week']} starts before predecessor {pred} finished in wk{pred_finish}."})

    # --- Scenario-specific hard rules ---
    if scenario == "A" and result["eclo_nights_total"] > 0:
        violations.append({"rule": "eclo", "severity": "hard",
                            "detail": f"{result['eclo_nights_total']} ECLO nights used in Scenario A (forbidden)."})

    if scenario == "B":
        for r in results_rows:
            if r["overrun_days"] > 0:
                violations.append({"rule": "planned_date", "severity": "hard",
                                    "detail": f"{r['contract_number']}: {r['overrun_days']} day(s) overrun -- Scenario B requires planned completion dates to be met."})

    if scenario == "C":
        # Independently re-derive each line's ECLO week-span from the raw
        # access rows (not from the solver's own bookkeeping), INCLUDING
        # cross-line exposure for Live activities that cross the interchange.
        eclo_weeks_by_line = {}
        for row in result["schedule_access_rows"]:
            if not row["eclo"]:
                continue
            aid = row["activity_id"]
            act_locs = [r["location_id"] for r in result["schedule_occupancy_rows"] if r["activity_id"] == aid and r["week"] == row["week"]]
            lines_touched = set(loc.split(":")[1] for loc in act_locs)
            for ln in lines_touched:
                eclo_weeks_by_line.setdefault(ln, set()).add(row["week"])
        for ln, weeks in eclo_weeks_by_line.items():
            if weeks and (max(weeks) - min(weeks) + 1) > 2:
                violations.append({"rule": "eclo_continuity", "severity": "hard",
                                    "detail": f"Line {ln}: ECLO used across weeks {sorted(weeks)}, spanning more than the allowed 2 continuous weeks."})

    return violations


# ------------------------------------------------------------
# F. OUTPUT + UI DATA ADAPTERS
# ------------------------------------------------------------

def comp_write_outputs(result, rows, directory):
    os.makedirs(directory, exist_ok=True)
    access_path = os.path.join(directory, "SCHEDULE_ACCESS.csv")
    occ_path = os.path.join(directory, "SCHEDULE_OCCUPANCY.csv")
    results_path = os.path.join(directory, "RESULTS.csv")
    pd.DataFrame(result["schedule_access_rows"], columns=["activity_id", "access_seq", "week", "eclo", "access_night"]).to_csv(access_path, index=False)
    pd.DataFrame(result["schedule_occupancy_rows"], columns=["activity_id", "week", "location_id", "co_share_group"]).to_csv(occ_path, index=False)
    pd.DataFrame(rows, columns=["scenario", "contract_number", "simulated_completion_date", "overrun_days"]).to_csv(results_path, index=False)
    return access_path, occ_path, results_path


def comp_get_timeline(result):
    """Rows = (line, bound), columns = week -> set of activity_ids scheduled
    there that week (deduped across that activity's several locations)."""
    cells = {}
    line_bounds = set()
    for row in result["schedule_occupancy_rows"]:
        loc = row["location_id"]
        parts = loc.split(":")
        line, bound = parts[1], parts[-1]
        line_bounds.add((line, bound))
        key = (line, bound, row["week"])
        cells.setdefault(key, set()).add(row["activity_id"])
    return sorted(line_bounds), cells


def comp_get_weekly_access_rows(result, instance=None):
    """One row per scheduled access night. Each row carries a single
    'location' -- picked the exact same way comp_build_map_closures picks
    its arrow's target station (the occupied sector nearest the start of
    the line, by seq) -- so the access table and the map arrow always show
    the same place. This is what makes a 3-week activity across 3 sectors
    show location #1 in week 1, #2 in week 2, #3 in week 3, instead of
    listing every sector it ever touches all at once.

    'instance' defaults to the module's own CURRENT_INSTANCE so existing
    callers that only pass 'result' keep working unchanged."""
    if instance is None:
        instance = CURRENT_INSTANCE
    sector_by_id = comp_build_sector_index(instance["SECTORS"]) if instance is not None else {}

    occupancy_by_access = {}
    for row in result["schedule_occupancy_rows"]:
        key = (row["activity_id"], row["week"])
        occupancy_by_access.setdefault(key, []).append(row["location_id"])

    def primary_location(locations):
        best_loc, best_seq = None, None
        for loc in locations:
            kind, core, _bound = parse_location_id(loc)
            if kind == "SEC" and core in sector_by_id:
                seq = int(sector_by_id[core]["seq"])
                if best_seq is None or seq < best_seq:
                    best_loc, best_seq = loc, seq
        if best_loc is not None:
            return best_loc
        return sorted(locations)[0] if locations else None

    rows = []
    for row in result["schedule_access_rows"]:
        locations = sorted(set(occupancy_by_access.get((row["activity_id"], row["week"]), [])))
        rows.append({
            **row,
            "locations": locations,                    # full set, kept for any existing callers
            "location": primary_location(locations),   # the ONE location to display -- matches the map
        })
    return rows

MAP_STATION_X = {
    "S01": 143, "S02": 275, "S03": 405, "S04": 537,
    "H01": 668, "H02": 799, "S05": 931, "S06": 1064,
    "S07": 1195, "S08": 1327,
    "S11": 143, "S12": 275, "S13": 405, "S14": 537,
    "S15": 931, "S16": 1064, "S17": 1195, "S18": 1327,
}

# Base-map geometry (must match the Alpha/Beta rows drawn in the network
# map SVG): Alpha's EB row sits at y=214, its station row at y=244, its WB
# row at y=275. Beta's EB row sits at y=521, its station row at y=552, its
# WB row at y=582. The closure arrows live in the gap between the two
# blocks -- Alpha's below its own WB row, Beta's above its own EB row --
# each pointing back toward its line without ever crossing that line.
# Alpha's numbers (335 -> 300, i.e. entirely below WB=275) are the
# reference behaviour; Beta's are the same offsets mirrored upward so its
# arrow stays entirely ABOVE its EB=521 row instead of crossing past it.
_ALPHA_WB_Y = 275
_BETA_EB_Y = 521
_ARROW_FAR_OFFSET = 60   # tail, further from the line
_ARROW_NEAR_OFFSET = 25  # tip, closer to the line (but not touching it)
_LABEL_OFFSET = 75       # label, furthest from the line

ALPHA_ARROW_START = _ALPHA_WB_Y + _ARROW_FAR_OFFSET    # 335 (below WB)
ALPHA_ARROW_END = _ALPHA_WB_Y + _ARROW_NEAR_OFFSET      # 300 (below WB, near it)
ALPHA_LABEL_Y = _ALPHA_WB_Y + _LABEL_OFFSET             # 350
BETA_ARROW_START = _BETA_EB_Y - _ARROW_FAR_OFFSET       # 461 (above EB)
BETA_ARROW_END = _BETA_EB_Y - _ARROW_NEAR_OFFSET        # 496 (above EB, near it)
BETA_LABEL_Y = _BETA_EB_Y - _LABEL_OFFSET               # 446

# H01/H02 are drawn with a solid black vertical connector straight down
# from Alpha's interchange circle to Beta's (see the base map SVG). An
# arrow aimed straight up/down at x=668 or x=799 would run right on top of
# that connector, so interchange-bound arrows get a separate tail x,
# offset sideways, and only meet the true station x at the tip -- i.e. the
# arrow approaches H01/H02 at an angle instead of straight down the
# connector line.
INTERCHANGE_STATIONS = {"H01", "H02"}
INTERCHANGE_ANGLE_OFFSET = 42


def comp_build_map_closures(instance, result):
    """Build one directional arrow for each activity access and week."""
    sectors = instance["SECTORS"]
    sector_by_id = comp_build_sector_index(sectors)
    occupancy_by_access = {}
    for row in result["schedule_occupancy_rows"]:
        occupancy_by_access.setdefault((row["activity_id"], row["week"]), set()).add(row["location_id"])

    grouped_arrows = {}
    for access in result["schedule_access_rows"]:
        aid = access["activity_id"]
        locations = occupancy_by_access.get((aid, access["week"]), set())
        by_line_bound = {}
        for location in locations:
            kind, core, bound = parse_location_id(location)
            if kind != "SEC" or core not in sector_by_id:
                continue
            sector = sector_by_id[core]
            by_line_bound.setdefault((sector["line_code"], bound), []).append(sector)

        for (line, bound), occupied_sectors in by_line_bound.items():
            target_sector = min(occupied_sectors, key=lambda sector: int(sector["seq"]))
            target_station = str(target_sector["from_station_id"])
            if target_station not in MAP_STATION_X:
                target_station = str(target_sector["to_station_id"])
            if target_station not in MAP_STATION_X:
                continue
            alpha = line == "ALP"
            arrow_x = MAP_STATION_X[target_station]
            # Tail x: same as the tip for a normal station (straight arrow),
            # but offset sideways for H01/H02 so the shaft doesn't overlap
            # the black interchange connector -- shifted toward the outer
            # sectors (away from the other interchange station) on each side.
            arrow_base_x = arrow_x
            if target_station == "H01":
                arrow_base_x = arrow_x - INTERCHANGE_ANGLE_OFFSET
            elif target_station == "H02":
                arrow_base_x = arrow_x + INTERCHANGE_ANGLE_OFFSET
            arrow_key = (int(access["week"]), line, bound, target_station)
            arrow = grouped_arrows.setdefault(arrow_key, {
                "week": int(access["week"]),
                "arrow_x": arrow_x,
                "arrow_base_x": arrow_base_x,
                "arrow_start": ALPHA_ARROW_START if alpha else BETA_ARROW_START,
                "arrow_end": ALPHA_ARROW_END if alpha else BETA_ARROW_END,
                "label_y": ALPHA_LABEL_Y if alpha else BETA_LABEL_Y,
                "marker": "map-arrow-up" if alpha else "map-arrow-down",
                "is_interchange": target_station in INTERCHANGE_STATIONS,
                "bound": bound,
            })
            arrow.setdefault("activity_ids", set()).add(str(aid))

    arrows = []
    for arrow in grouped_arrows.values():
        # Comma, no space -- e.g. "A01,A02" when two activities share the
        # same sector/week/target station, so they render as one arrow.
        arrow["activity_label"] = ",".join(sorted(arrow.pop("activity_ids")))
        arrows.append(arrow)

    # Keep labels for neighboring closures from being rendered on top of one
    # another when several activities use the same line and week.
    for group_key in {(arrow["week"], arrow["marker"]) for arrow in arrows}:
        group = sorted(
            (arrow for arrow in arrows if (arrow["week"], arrow["marker"]) == group_key),
            key=lambda arrow: arrow["arrow_x"],
        )
        offsets = [0]
        for index in range(1, len(group)):
            step = (index + 1) // 2
            offsets.append(step * (18 if index % 2 else -18))
        for arrow, offset in zip(group, offsets):
            arrow["label_y"] += offset

    return sorted(arrows, key=lambda arrow: (arrow["week"], arrow["arrow_x"], arrow["bound"], arrow["activity_label"]))

NATURE_COLORS = {
    "Non-live (Consist)": "#F7E9A0",
    "Non-live (Others)": "#AFCFEF",
    "Live": "#F3B79C",
}

def comp_build_activity_details(instance, result, results_rows, scenario):
    """One comprehensive record per activity for the detail popup -- covers
    every field listed in the spec (activity/schedule/contract/locations/
    safety-sharing/result), built once server-side so the template stays
    simple Jinja rather than complex cross-referencing logic."""
    acts = result["acts"].set_index("activity_id")
    proj = instance["PROJECT_DETAILS"].set_index("contract_number")
    buf_rules = instance["BUFFER_LOCATION"].set_index("nature_of_works")
    results_by_contract = {r["contract_number"]: r for r in results_rows}

    access_by_activity, occ_by_activity = {}, {}
    for row in result["schedule_access_rows"]:
        access_by_activity.setdefault(row["activity_id"], []).append(row)
    for row in result["schedule_occupancy_rows"]:
        occ_by_activity.setdefault(row["activity_id"], []).append(row)

    details = {}
    for aid, act in acts.iterrows():
        contract = proj.loc[act["contract_number"]]
        buffer_rule = buf_rules.loc[act["nature_of_activity"]]
        accesses = sorted(access_by_activity.get(aid, []), key=lambda r: r["access_seq"])
        occ = occ_by_activity.get(aid, [])
        weeks_used = sorted(set(r["week"] for r in accesses))
        locations = sorted(set(r["location_id"] for r in occ))
        delivered = round(result["workload_delivered"].get(aid, 0.0), 1)
        shortfall = result["workload_shortfall"].get(aid)
        contract_result = results_by_contract.get(act["contract_number"])

        share_groups = set(r["co_share_group"] for r in occ)
        sharing_with = set()
        for row in result["schedule_occupancy_rows"]:
            if row["co_share_group"] in share_groups and row["activity_id"] != aid:
                sharing_with.add(row["activity_id"])

        details[aid] = {
            "activity_id": aid, "contract_number": act["contract_number"],
            "start_location": act["start_location_id"], "end_location": act["end_location_id"],
            "nature": act["nature_of_activity"], "access_type": act["access_type"],
            "total_accesses": act["total_accesses"], "delivered": delivered,
            "planned_start_date": act["planned_start_date"].isoformat(),
            "activity_priority": int(act["activity_priority"]),
            "weeks_used": weeks_used,
            "accesses": [{"seq": r["access_seq"], "week": r["week"], "eclo": bool(r["eclo"]), "access_night": r["access_night"]} for r in accesses],
            "completion_week": result["activity_completion"].get(aid),
            "contract_priority": int(contract["contract_priority"]),
            "planned_completion_date": str(contract["planned_completion_date"]),
            "contract_completion_date": str(contract["contract_completion_date"]),
            "max_access_per_week": int(contract["number_of_maximum_access_per_week"]),
            "num_workfronts": int(contract["number_of_workfronts"]),
            "locations": locations,
            "is_live": act["nature_of_activity"] == "Live",
            "buffer_sectors": int(buffer_rule["up_to_buffer_sectors"]),
            "opposite_bound_mirrored": bool(buffer_rule["opposite_bound_required"]),
            "touches_interchange": any("H01_H02" in l for l in locations),
            "sharing_with": sorted(sharing_with),
            "fully_completed": shortfall is None,
            "shortfall": round(shortfall, 1) if shortfall else None,
            "contract_overrun_days": contract_result["overrun_days"] if contract_result else None,
            "simulated_completion_date": contract_result["simulated_completion_date"] if contract_result else None,
            "pc_border": act["access_type"] == "PC",
            "color": NATURE_COLORS.get(act["nature_of_activity"], "#E5E5E5"),
        }
    return details


# ===============================================