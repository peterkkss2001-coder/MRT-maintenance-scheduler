# MRT Maintenance Scheduler

## 1. Overview

The MRT Maintenance Scheduler is a Flask-based competition web application for **Problem Statement 1 (PS1) — Railway Track Access Optimisation**.

The application schedules **physical railway track and platform access**, not employees. Its competition engine is implemented in `scheduler.py`, while `main.py` provides the web interface, authentication, upload workflow, result visualisation, CSV download, and Gemini explanation. The scheduler module is intentionally separated from the Flask application so that competition logic remains in one place.

The application supports the complete PS1 workflow:

1. Supervisor login
2. Upload a PS1 problem set as CSV files or a ZIP archive
3. Validate the uploaded problem set
4. Run Scenario A, B, or C
5. Generate the three required submission CSV files
6. Re-read those CSV files and validate the actual generated files
7. Display feasibility, violations, scores, timeline, access map, and activity details
8. Use Vertex AI Gemini to explain the deterministic validator result
9. Download the generated submission CSV files

`main.py` does not use the retired employee-based scheduling system. `scheduler.py` is the competition scheduling engine.

---

## 2. Project Files

### `main.py`

The Flask web application.

Responsibilities include:

- Login and registration
- Supervisor-only access control
- Home page
- Line Access Map page
- PS1 problem-set upload
- Problem-set validation
- Scenario A/B/C execution
- Calling the competition engine in `scheduler.py`
- Calling the file-based submission validator
- Displaying results
- Displaying the timeline
- Displaying the Line Access Map
- Displaying activity details
- Requesting a Gemini explanation
- Downloading the three generated CSV files

The application reads configuration from `.env` when present.

### `scheduler.py`

The competition engine.

Responsibilities include:

- PS1 input-file parsing
- Input validation
- Network and location footprint expansion
- Buffer calculations
- Live opposite-bound mirroring
- Live interchange handling
- Possession and PM/PC/C grouping logic
- Scenario A/B/C scheduling
- SciPy/HiGHS MILP optimisation
- Score calculation
- Submission-file validation
- CSV generation
- Timeline data
- Map-closure/access data
- Activity-detail data

The module explicitly treats track/platform capacity as the scheduled resource rather than employees.

### `requirements.txt`

Lists the Python dependencies required by the application:

```text
Flask>=3.0,<4
gunicorn>=23,<24
pandas>=2.2,<3
scipy>=1.13,<2
python-dotenv>=1.0,<2
google-genai>=1.0,<2
google-auth>=2.30,<3
```

### `validation(1).py`

This file contains an older employee-dataset loader and an older Gemini helper. It is **not imported by the final `main.py` or `scheduler.py` runtime path** and is not required for the PS1 competition workflow.

The final application uses `scheduler.py` for competition validation and `main.py` for the current Gemini explanation flow.

---

## 3. System Requirements

Recommended environment:

- Python 3.11 or Python 3.12
- Internet access for installing Python packages
- A Google Cloud project when using Vertex AI Gemini
- Google Cloud authentication when using Vertex AI Gemini

The scheduler uses:

- Flask for the web application
- Pandas for CSV/data processing
- SciPy HiGHS MILP for optimisation
- python-dotenv for `.env` configuration
- Google Gen AI SDK and Google Auth for Vertex AI Gemini

---

## 4. Installation

Open a terminal in the project directory.

### Create an optional virtual environment

```bash
python -m venv .venv
```

Activate it on Linux/macOS:

```bash
source .venv/bin/activate
```

Activate it on Windows:

```powershell
.venv\Scripts\activate
```

### Install dependencies

```bash
pip install -r requirements.txt
```

---

## 5. Google Cloud Shell Setup

The application is suitable for running in Google Cloud Shell and can later be deployed to Cloud Run.

From Cloud Shell:

```bash
cd /home/<your-user>/<project-folder>
pip install -r requirements.txt
```

Run the application with:

```bash
python main.py
```

The application listens on:

```text
0.0.0.0:<PORT>
```

and defaults to port:

```text
8080
```

For Cloud Run, the application honours the `PORT` environment variable.

In Cloud Shell, use **Web Preview** and select port `8080` when running the development server.

For a production deployment, use the provided Gunicorn configuration/Docker deployment rather than Flask's development server.

---

## 6. Environment Configuration

Create a `.env` file in the same directory as `main.py` when environment configuration is needed.

Example:

```env
FLASK_SECRET_KEY=replace-with-a-strong-secret
SUPERVISOR_USERNAME=supervisor
SUPERVISOR_PASSWORD=replace-with-a-strong-password

GOOGLE_CLOUD_PROJECT=your-google-cloud-project-id
GOOGLE_CLOUD_LOCATION=global
GEMINI_MODEL=gemini-2.5-flash

PORT=8080
```

### Environment variables

| Variable | Purpose | Default |
|---|---|---|
| `FLASK_SECRET_KEY` | Flask session secret | `change-me-in-production` |
| `SUPERVISOR_USERNAME` | Supervisor login username | `supervisor` |
| `SUPERVISOR_PASSWORD` | Supervisor login password | `super123` |
| `GOOGLE_CLOUD_PROJECT` | Google Cloud project used by Vertex AI | Not set |
| `GOOGLE_CLOUD_LOCATION` | Vertex AI location | `global` |
| `GEMINI_MODEL` | Gemini model name | `gemini-2.5-flash` |
| `PORT` | HTTP server port | `8080` |
| `COMPETITION_OUTPUT_DIR` | Root directory for generated scenario outputs | `competition_output` beside `scheduler.py` |

Do not commit real credentials, API keys, passwords, or other secrets to GitHub.

---

## 7. Login and Access Control

The current application has:

- Login
- Registration
- Logout
- Supervisor-only competition operations

Competition routes require the session role to be `supervisor`.

The built-in default supervisor is:

```text
Username: supervisor
Password: super123
```

These values should be changed through environment variables before any real deployment.

### Important limitation

Registered users are stored in the Python process's in-memory `USERS` dictionary. They are not persisted in a database. A process restart or Cloud Run instance replacement can therefore remove accounts created through the registration page.

For a competition demonstration this can be acceptable, but persistent production authentication would require a database or identity service.

---

# 8. PS1 Input Data

The scheduler expects eight PS1 instance datasets.

The canonical file names and required columns are defined by `scheduler.py`.

## 8.1 `LINES`

Required columns:

```text
line_code
line_name
```

Defines the railway lines, such as Alpha and Beta.

## 8.2 `STATIONS`

Required columns:

```text
station_id
line_code
seq
is_interchange
```

Defines station order along each line and identifies interchange stations.

## 8.3 `SECTORS`

Required columns:

```text
sector_id
line_code
from_station_id
to_station_id
seq
is_shared
```

Defines the railway tunnel sectors.

The scheduler expands a working range from `start_location_id` to `end_location_id` across the required sector sequence.

## 8.4 `LOCATION_SUPPLY`

Required columns:

```text
location_id
location_kind
line_code
bound
supply_capacity
```

Defines available capacity at physical railway locations, including tunnel and platform locations.

## 8.5 `BUFFER_LOCATION`

Required columns:

```text
nature_of_works
up_to_buffer_sectors
opposite_bound_required
```

Defines the safety buffer associated with each nature of activity.

## 8.6 `PARAMETERS`

Required columns:

```text
key
value
```

The scheduler expects at least:

```text
horizon_start
horizon_weeks
```

These define the scheduling horizon.

## 8.7 `PROJECT_DETAILS`

Required columns:

```text
contract_number
contract_description
contract_award_date
activity_type
nature_of_activity
contract_priority
contract_completion_date
planned_completion_date
number_of_workfronts
access_type
number_of_maximum_access_per_week
```

This defines contract-level rules and scheduling parameters.

`planned_completion_date` is the scenario target used by the solver/validator.

`contract_completion_date` is loaded for context/display and is not used as a solver bound in the current implementation.

## 8.8 `ACTIVITY_DETAILS`

Required columns:

```text
activity_id
contract_number
activity_type
start_location_id
end_location_id
total_accesses
planned_start_date
predecessor_activity_id
activity_priority
```

This defines the individual activities that must be scheduled.

---

# 9. Input Validation

Before scheduling, the application validates the problem set.

The input validator checks, among other things:

- Required files
- Required columns
- Activity-to-contract references
- Predecessor references
- Self-referencing predecessors
- Cyclic predecessor relationships
- Location identifiers
- Sector references
- Nature-of-work references
- `horizon_start`
- `horizon_weeks`

The application will not allow a scenario to run until the uploaded problem set passes the input validation step.

---

# 10. Location and Railway Footprint Model

An activity is defined by:

```text
start_location_id
end_location_id
```

The scheduler expands that range into:

- Tunnel sectors
- Platform sectors
- Required safety buffers

The `parse_location_id()` helper interprets location IDs as:

```text
KIND:CORE:BOUND
```

For example:

```text
SEC:ALP:S02_S03:EB
```

The activity footprint is expanded according to the sector sequence.

---

# 11. Safety and Possession Rules

The scheduler implements the main PS1 physical and possession rules represented by the data model.

## 11.1 Workload conservation

Every activity must deliver its required workload.

Standard access:

```text
1.0 work units
```

ECLO access:

```text
1.5 work units
```

The validator independently recomputes the delivered workload from the generated `SCHEDULE_ACCESS.csv`.

An incomplete activity is treated as a hard violation.

## 11.2 Planned start

An activity cannot access the railway before its planned start week.

## 11.3 Buffers

The activity nature determines the number of buffer sectors.

The current scheduler uses the `BUFFER_LOCATION` table to determine the buffer.

## 11.4 Live opposite-bound mirroring

Live work mirrors the occupied tunnel footprint to the opposite bound.

For example:

```text
EB → corresponding WB closure
WB → corresponding EB closure
```

## 11.5 Interchange rule

For Live activities reaching the interchange, the scheduler also includes the corresponding `H01_H02` tunnel/platform locations on the other line.

Non-Live work does not use this Live interchange crossover rule.

## 11.6 PM / PC / C possession mixes

A possession group must satisfy one of:

```text
1 PM alone
```

or

```text
1 PC + up to 3 C
```

or

```text
up to 4 C
```

The current helper `comp_group_can_accept()` implements those legality rules.

## 11.7 Co-sharing

PS1 defines:

```text
same location + same week + same co_share_group
```

as one possession.

Activities in the same legal co-share group are allowed to share that possession.

Different co-share groups represent separate possessions.

## 11.8 Weekly access allocation

The weekly access budget is checked by:

```text
(contract_number, activity_type, week)
```

using:

```text
number_of_maximum_access_per_week
```

## 11.9 Workfront limits

Concurrent work is limited by:

```text
(contract_number, activity_type, week, access_night)
```

using:

```text
number_of_workfronts
```

## 11.10 Predecessors

A dependent activity must start strictly after its predecessor has completed.

The current instance contains the known dependency pairs:

```text
A003 → A004
A012 → A013
A037 → A038
A048 → A049
A050 → A051
A065 → A066
```

The scheduler applies strict sequencing to predecessor relationships rather than allowing the predecessor and dependent activity to finish/start in the same week.

---

# 12. Scenarios

The application offers three PS1 scenarios.

## Scenario A — Strict Supply, Flexible Schedule

Scenario A uses:

- Rigid location supply
- Flexible completion timing
- ECLO forbidden

The objective is priority-weighted completion overrun.

Scenario A objective:

```text
priority-weighted overrun
```

The current priority structure is:

```text
Contract priority 1 → weight 100
Contract priority 2 → weight 10
Contract priority 3 → weight 1
```

Activity priority adds the configured nudge:

```text
Activity priority 1 → +0.3
Activity priority 2 → +0.2
Activity priority 3 → +0.0
```

The final overrun contribution is therefore calculated from the contract priority tier, the activity priority nudge, and the number of overrun days.

## Scenario B — Strict Schedule, Flexible Supply

Scenario B uses:

- Hard planned completion dates
- Flexible supply through excess possession/access capacity
- ECLO allowed
- No overrun allowed in a feasible result

Scenario B objective:

```text
7 × excess_access_nights_total
+
5 × eclo_nights_total
```

There is no overrun term in the Scenario B objective.

## Scenario C — Balanced / Elastic

Scenario C combines:

- Completion overrun
- Limited excess possessions
- ECLO

Scenario C objective:

```text
priority-weighted overrun
+
7 × excess_access_nights_total
+
5 × eclo_nights_total
```

The current Scenario C model permits a limited one-possession excess allowance per location/week and uses an ECLO window of at most two calendar weeks per affected line.

For cross-line Live activities, ECLO constraints apply to all affected lines.

---

# 13. Optimisation Engine

The competition scheduler uses:

```text
SciPy
HiGHS MILP
```

The main binary decision variables represent:

- Whether an activity receives access in a week
- Whether the access uses ECLO
- Which weekly access-night index is used
- Scenario C ECLO-window decisions
- Possession-count accounting variables
- Completion and overrun variables

The solver uses a bounded time limit:

```text
Scenario A: 45 seconds
Scenario B: 45 seconds
Scenario C: 15 seconds
```

The current implementation does not claim global optimality when the MILP reaches its time limit.

Scenario C has a fallback mechanism: when the C solver cannot produce an incumbent, it can use a separately solved Scenario A schedule as a feasible C fallback, because Scenario C relaxes supply and permits ECLO.

---

# 14. Generated Output Files

For each selected scenario, the application writes three files.

Output directory:

```text
competition_output/
├── scenario_A/
├── scenario_B/
└── scenario_C/
```

## 14.1 `SCHEDULE_ACCESS.csv`

Schema:

```text
activity_id,access_seq,week,eclo,access_night
```

Meaning:

- `activity_id` — scheduled activity
- `access_seq` — sequential access number for that activity
- `week` — scheduling week
- `eclo` — `0` for standard access, `1` for ECLO
- `access_night` — the local access-night index within the contract/activity-type/week allocation

## 14.2 `SCHEDULE_OCCUPANCY.csv`

Schema:

```text
activity_id,week,location_id,co_share_group
```

Meaning:

- `activity_id` — activity occupying the location
- `week` — scheduling week
- `location_id` — tunnel/platform location occupied
- `co_share_group` — possession-group identifier

## 14.3 `RESULTS.csv`

Schema:

```text
scenario,contract_number,simulated_completion_date,overrun_days
```

The validator requires one scenario per results file.

---

# 15. Submission Validation

The application does not rely only on the solver's in-memory result.

After scheduling:

1. The three CSV files are written to disk.
2. The application reads the generated files back.
3. `comp_validate_submission()` validates the actual files against the original instance and selected scenario.
4. Feasibility is determined from the resulting hard-violation list.
5. Soft scores are independently recalculated from the submission files.

This is important because it tests the actual submission artefacts rather than trusting only the solver's internal bookkeeping.

## Validation checks

The file-based validator checks:

- Output schema
- Activity references
- Access sequence numbering
- Duplicate access rows
- One access per activity/week
- Horizon
- Planned start
- ECLO restrictions
- Workload conservation
- Occupancy references
- Duplicate occupancy rows
- Every access has occupancy
- Every occupancy has a corresponding access
- Required physical occupancy footprint
- Location capacity
- PM/PC/C legality
- Weekly allocation limits
- Workfront limits
- Predecessor sequencing
- `RESULTS.csv` scenario consistency
- `RESULTS.csv` contract set
- `RESULTS.csv` completion-date consistency
- Scenario B planned-date hard constraint
- Scenario C ECLO continuity

The current submission validator deliberately does not try to reconstruct simultaneous buffer conflicts from different `co_share_group` labels at the same location/week because the PS1 output schema does not provide a global cross-contract night identifier. Physical closure/buffer conflicts are enforced by the scheduling model.

The official competition validator remains the final authority.

---

# 16. Score Calculation

The application calculates the soft scores from the generated submission files.

### Priority-weighted overrun

For each overrun activity:

```text
contract priority weight
×
(1 + activity priority nudge)
×
overrun days
```

Priority weights:

```text
P1 = 100
P2 = 10
P3 = 1
```

Activity nudges:

```text
priority 1 = +0.3
priority 2 = +0.2
priority 3 = +0.0
```

### Scenario A

```text
Score A = priority-weighted overrun
```

### Scenario B

```text
Score B =
7 × excess access-nights
+
5 × ECLO nights
```

### Scenario C

```text
Score C =
priority-weighted overrun
+
7 × excess access-nights
+
5 × ECLO nights
```

All of these are penalty values; the scoring design in the PS1 specification treats lower penalty as better.

---

# 17. Timeline

After a schedule has been generated, the UI builds a weekly timeline.

The timeline is derived from `SCHEDULE_OCCUPANCY.csv`-equivalent data and is organised by:

```text
Line
Bound
Week
```

Activities appear as clickable activity chips.

The activity colour represents the nature of the activity:

```text
Non-live (Consist) → soft yellow
Non-live (Others)  → soft blue
Live               → soft red/orange
```

PC activities have a visual border indicating the possession type.

---

# 18. Line Access Map

The UI includes a railway network access map for:

```text
Line Alpha
Line Beta
```

with:

- EB/WB directions
- Station markers
- H01/H02 interchange connections
- Scheduled access arrows
- Week-based access information
- Activity IDs associated with map access

The map is generated from the actual scheduler result rather than the old employee schedule.

The map can therefore be used to inspect where scheduled activities affect each line.

---

# 19. Activity Details

The activity-detail view provides a consolidated record for each activity.

The current implementation includes information such as:

- Activity ID
- Contract number
- Start/end locations
- Nature
- Access type
- Total workload
- Delivered workload
- Planned start
- Activity priority
- Weeks used
- Access sequence
- Access-night
- ECLO status
- Completion week
- Contract priority
- Planned completion date
- Contract completion date
- Weekly access limit
- Workfront limit
- Occupied locations
- Live status
- Buffer sectors
- Opposite-bound mirroring
- Interchange involvement
- Co-sharing information
- Completion status
- Workload shortfall
- Contract overrun
- Simulated completion date

---

# 20. Gemini / Vertex AI Explanation

Gemini is used only as an **explanation layer**.

The deterministic validator decides:

```text
FEASIBLE
or
NOT FEASIBLE
```

Gemini does not decide feasibility.

The application sends the validator report to Gemini and asks it to explain:

- Overall validator status
- Important hard violations
- Successful checks
- Affected activity IDs
- Locations and weeks when available
- Main score metrics

The prompt explicitly instructs Gemini:

- The deterministic validator is authoritative
- Do not invent rules
- Do not change the feasibility decision
- Do not make scheduling decisions
- Keep the explanation concise

The application uses the Google Gen AI SDK with Vertex AI:

```python
genai.Client(
    vertexai=True,
    project=project,
    location=location,
)
```

The default model is:

```text
gemini-2.5-flash
```

### Authentication

The application first looks for:

```text
GOOGLE_CLOUD_PROJECT
```

and otherwise attempts to obtain the current project through Google Application Default Credentials.

The current code does not use a `GOOGLE_API_KEY` environment variable for the Vertex AI path.

### Gemini failure behaviour

If the Google AI client is unavailable or the service call fails, the application provides a deterministic fallback explanation and displays the Google AI service error as a note.

The scheduler and validator continue to operate without Gemini.

---

# 21. Web Routes

The main Flask routes are:

| Route | Purpose |
|---|---|
| `/login` | Sign in |
| `/register` | Create supervisor account |
| `/logout` | Sign out |
| `/` | Home page |
| `/network-map` | Line Access Map |
| `/problem-statement/` | Main competition scheduler |
| `/problem-statement/competition/upload` | Upload PS1 files |
| `/problem-statement/restart` | Clear current dataset/results |
| `/problem-statement/competition/validate` | Validate uploaded problem set |
| `/problem-statement/competition/run` | Run Scenario A/B/C |
| `/problem-statement/competition/explain` | Regenerate Gemini explanation |
| `/problem-statement/competition/validate-outputs` | Revalidate generated CSVs |
| `/problem-statement/competition/export/<filename>` | Download a generated CSV |

---

# 22. Typical User Workflow

## Step 1 — Start the application

```bash
python main.py
```

## Step 2 — Sign in

Use the configured supervisor account.

## Step 3 — Upload the PS1 instance

Upload either:

- The individual eight CSV files, or
- A ZIP containing the CSV files

The application detects files using their canonical PS1 dataset names.

## Step 4 — Validate the problem set

Click the validation action.

The application checks the required instance structure and referential integrity.

## Step 5 — Select a scenario

Choose:

```text
Scenario A
Scenario B
Scenario C
```

## Step 6 — Run the scheduler

The application:

```text
Input instance
    ↓
MILP scheduler
    ↓
SCHEDULE_ACCESS.csv
SCHEDULE_OCCUPANCY.csv
RESULTS.csv
    ↓
File-based validator
    ↓
Feasible / violations / scores
    ↓
Gemini explanation
```

## Step 7 — Review the result

Review:

- Activity completion
- Contracts overrunning
- Total overrun
- Excess access-nights
- ECLO nights
- Objective score
- Hard violations
- Timeline
- Line Access Map
- Activity details
- Gemini explanation

## Step 8 — Download the submission

Download:

```text
SCHEDULE_ACCESS.csv
SCHEDULE_OCCUPANCY.csv
RESULTS.csv
```

---

# 23. Output Directory

By default:

```text
competition_output/
```

is created beside `scheduler.py`.

For example:

```text
competition_output/
├── scenario_A/
│   ├── SCHEDULE_ACCESS.csv
│   ├── SCHEDULE_OCCUPANCY.csv
│   └── RESULTS.csv
├── scenario_B/
│   ├── SCHEDULE_ACCESS.csv
│   ├── SCHEDULE_OCCUPANCY.csv
│   └── RESULTS.csv
└── scenario_C/
    ├── SCHEDULE_ACCESS.csv
    ├── SCHEDULE_OCCUPANCY.csv
    └── RESULTS.csv
```

The location can be changed with:

```env
COMPETITION_OUTPUT_DIR=/path/to/output
```

---

# 24. Troubleshooting

## Port 8080 already in use

Find the old Flask process:

```bash
ps -ef | grep '[p]ython.*main.py'
```

Then stop its PID:

```bash
kill <PID>
```

Start again:

```bash
python main.py
```

## `ModuleNotFoundError`

Install the requirements:

```bash
pip install -r requirements.txt
```

## `NATURE_COLORS is not defined`

Make sure the Cloud Shell `scheduler.py` is the current final version. `NATURE_COLORS` is defined in the final scheduler module and is used by the activity-detail UI.

## Gemini explanation is unavailable

A missing Gemini explanation does not mean the scheduler failed.

Check:

```bash
echo $GOOGLE_CLOUD_PROJECT
```

and verify Google Cloud authentication and Vertex AI access.

The deterministic validator can still produce the feasibility result and fallback explanation.

## `jupyter.runFileInteractive` not found

This is a Cloud Shell Editor/Jupyter command issue.

Run the application in the terminal instead:

```bash
python main.py
```

or use the editor command that runs the Python file in the terminal.

---

# 25. Deployment Notes for Google Cloud

The clean GitHub/deployment package contains only the files required for the current PS1 competition application plus deployment/configuration helpers:

```text
mrt-scheduler/
├── main.py
├── scheduler.py
├── requirements.txt
├── README.md
├── Dockerfile
├── .dockerignore
├── .gcloudignore
├── .gitignore
└── .env.example
```

The legacy `validation(1).py` employee-dataset module and other retired employee/shift files are intentionally excluded. They are not part of the current PS1 runtime and should not be restored into the repository.

The Flask application binds to `0.0.0.0` and honours the `PORT` environment variable, defaulting to `8080`.

For Cloud Run, the included `Dockerfile` uses Gunicorn to serve `main:app`. The included `requirements.txt` provides the runtime dependencies.

The Google Cloud service should also be configured with appropriate Vertex AI permissions so the Gemini explanation service can authenticate through Google Cloud.

---

# 26. Clean GitHub Repository

This repository intentionally contains only the current competition application. Do not upload generated outputs, Python cache directories, `.env`, API keys, service-account JSON files, or legacy employee-scheduling source files.

The `.gitignore` file excludes common local/runtime files. Use `.env.example` as the safe template for environment variables and keep the real `.env` local to the deployment environment.

To replace an existing GitHub repository with this clean version, delete the old repository files from the working copy, copy in the files from this package, commit the replacement, and push. The repository should not retain duplicate versions such as `final.py`, `final(1).py`, `scheduler(2).py`, `validation.py`, or old employee scheduling modules.

# 26. Security Considerations

Before deployment:

1. Change the default supervisor password.
2. Set a strong `FLASK_SECRET_KEY`.
3. Do not commit `.env` files containing secrets.
4. Do not commit Google API keys or service-account private keys.
5. Use Google Cloud identity/ADC/Vertex AI authentication instead of embedding credentials in source code.
6. Consider persistent authentication storage if the application will be used by multiple users.
7. Use HTTPS through the Cloud Run endpoint.
8. Treat uploaded PS1 files and generated outputs as competition-sensitive data.

---

# 27. Architecture Summary

```text
                    ┌─────────────────────────┐
                    │        Browser          │
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │        main.py          │
                    │ Flask Web Application    │
                    │                         │
                    │ Login / Upload / UI     │
                    │ Timeline / Map / Export │
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │      scheduler.py       │
                    │ Competition Engine       │
                    │                         │
                    │ PS1 Parsing             │
                    │ Footprint Expansion     │
                    │ Constraints             │
                    │ MILP Optimisation       │
                    │ Scoring                 │
                    │ Output Generation       │
                    └────────────┬────────────┘
                                 │
                                 ▼
                 ┌────────────────────────────────┐
                 │ Three submission CSV files     │
                 │                                │
                 │ SCHEDULE_ACCESS.csv            │
                 │ SCHEDULE_OCCUPANCY.csv         │
                 │ RESULTS.csv                    │
                 └────────────────┬───────────────┘
                                  │
                                  ▼
                 ┌────────────────────────────────┐
                 │ Deterministic Submission      │
                 │ Validator                     │
                 │                                │
                 │ Hard rules + scores            │
                 └────────────────┬───────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
                    ▼                           ▼
          ┌──────────────────┐       ┌─────────────────────┐
          │ Feasibility and  │       │ Vertex AI Gemini    │
          │ score report     │──────►│ Explanation only    │
          └──────────────────┘       └─────────────────────┘
```

---

# 28. Important Design Principle

The final application separates **decision-making from explanation**:

```text
Scheduler
    ↓
Generates schedule

Deterministic validator
    ↓
Determines feasibility and score

Gemini
    ↓
Explains the validator result
```

Gemini is not the source of truth for competition feasibility.

The PS1 official validator remains the final authority for competition scoring and acceptance.

---

# 29. Quick Start

For a new Cloud Shell environment:

```bash
cd /home/<your-user>/<project-folder>

pip install -r requirements.txt

python main.py
```

Then open Cloud Shell Web Preview on port `8080`.

Application flow:

```text
Login
→ Upload PS1 instance
→ Validate
→ Select Scenario
→ Run
→ Review validator result
→ Review timeline/map
→ Read Gemini explanation
→ Download the three CSV files
```

---

## License / Competition Use

This application is intended for the MRT Maintenance Scheduler competition / PS1 railway track-access optimisation workflow.

Refer to the competition's official PS1 specification and validator for the definitive rules, acceptance criteria, and scoring.
