"""
MRT Maintenance Scheduler — competition web application.

The application contains only the PS1 competition workflow:
    - supervisor login
    - problem-set upload and validation
    - Scenario A / B / C scheduling
    - generated submission CSVs
    - deterministic file-based validation
    - Vertex AI Gemini explanation of the validator report
    - competition timeline / access map / activity details

The retired employee-based scheduler, worker accounts, employee roster,
weekly shift store, and Emergency Centre have been removed. The physical
resource being scheduled is track/platform capacity from the PS1 instance,
not employees.
"""

from __future__ import annotations

import json
import os
from functools import wraps

from dotenv import load_dotenv
from flask import (
    Flask,
    flash,
    get_flashed_messages,
    redirect,
    render_template_string,
    request,
    send_file,
    session,
    url_for,
)

import scheduler

try:
    from google import genai
    import google.auth
except ImportError:
    genai = None
    google = None

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

CURRENT_AI_JUSTIFICATION = None
CURRENT_VALIDATION_REPORT = None

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-me-in-production")

SUPERVISOR_USERNAME = os.environ.get("SUPERVISOR_USERNAME", "supervisor")
SUPERVISOR_PASSWORD = os.environ.get("SUPERVISOR_PASSWORD", "super123")
USERS = {
    SUPERVISOR_USERNAME: {
        "password": SUPERVISOR_PASSWORD,
        "role": "supervisor",
    }
}


# ============================================================
# STYLING
# ============================================================

CSS = '\n:root {\n  --ink: #14261D; --ink-soft: #4B6355; --paper: #F5FAF7; --panel: #FFFFFF;\n  --line: #D7E6DC; --forest: #1B4332; --green: #2F8F62; --green-hover: #24704D;\n  --mint-bg: #E3F3EA; --sage: #8FBFA0; --red: #C1443D; --red-bg: #FBE9E7; --radius: 6px;\n}\n* { box-sizing: border-box; }\nbody { margin: 0; background: var(--paper); color: var(--ink); font-family: "Segoe UI", Arial, Helvetica, sans-serif; }\na { color: var(--green); }\n.login-wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px; }\n.login-box { background: var(--panel); padding: 2.2rem; border-radius: var(--radius); box-shadow: 0 4px 18px rgba(27,67,50,0.10); width: 100%; max-width: 360px; border-top: 4px solid var(--green); }\n.login-box h1 { font-size: 1.4rem; margin: 0 0 6px; color: var(--forest); }\n.login-box .sub { font-size: 0.85rem; color: var(--ink-soft); margin-bottom: 1.4rem; }\n.login-box label { display: block; font-size: 0.85rem; color: var(--ink-soft); margin-bottom: 1rem; }\n.login-box input { width: 100%; padding: 0.6rem; margin-top: 0.3rem; border: 1px solid var(--line); border-radius: var(--radius); font-size: 0.95rem; }\n.login-box button { width: 100%; background: var(--green); color: white; border: none; padding: 0.65rem; border-radius: var(--radius); cursor: pointer; font-size: 0.95rem; font-weight: 600; }\n.login-box button:hover { background: var(--green-hover); }\n.login-box .error { background: var(--red-bg); color: var(--red); padding: 0.6rem 0.8rem; border-radius: var(--radius); font-size: 0.82rem; margin-bottom: 1rem; }\n.app-header { background: var(--forest); color: white; padding: 16px 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }\n.app-header .brand { font-weight: 700; font-size: 16px; } .app-header .brand a { color: white; text-decoration: none; }\n.app-header .account { font-size: 0.82rem; display: flex; align-items: center; gap: 10px; }\n.app-header .role-badge { background: var(--green); padding: 2px 8px; border-radius: 999px; font-size: 0.7rem; text-transform: uppercase; }\n.app-header a.logout { color: #DCEEE3; text-decoration: none; font-weight: 600; } .app-header a.logout:hover { text-decoration: underline; }\n.app-body { padding: 1.2rem 1.6rem 3rem; max-width: 1200px; margin: 0 auto; }\n.topbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; }\nh1 { font-size: clamp(1.2rem, 2vw, 1.7rem); margin-bottom: 0.2rem; color: var(--forest); }\np.subtitle { color: var(--ink-soft); margin-top: 0; margin-bottom: 0.8rem; font-size: 0.9rem; }\n.tabs { display: flex; gap: 0.4rem; margin: 1rem 0 1.2rem; flex-wrap: wrap; }\n.tab { padding: 0.5rem 1.1rem; border-radius: 6px 6px 0 0; background: var(--mint-bg); color: var(--ink-soft); text-decoration: none; font-weight: 600; font-size: 0.85rem; }\n.tab.active { background: var(--forest); color: white; }\n.info-banner { background: var(--mint-bg); border: 1px solid var(--sage); color: var(--forest); padding: 0.7rem 1rem; border-radius: var(--radius); margin-bottom: 1rem; font-size: 0.88rem; }\n.error-banner { background: var(--red-bg); border: 1px solid var(--red); color: var(--red); padding: 0.7rem 1rem; border-radius: var(--radius); margin-bottom: 1rem; font-size: 0.88rem; }\n.legend { display: flex; gap: 1.2rem; margin-bottom: 1rem; flex-wrap: wrap; }\n.legend-item { display: flex; align-items: center; gap: 0.4rem; font-size: 0.78rem; color: var(--ink-soft); }\n.legend-swatch { width: 12px; height: 12px; border-radius: 3px; display: inline-block; flex-shrink: 0; }\n.table-wrap { width: 100%; overflow-x: auto; }\ntable { width: 100%; min-width: 720px; border-collapse: collapse; background: var(--panel); box-shadow: 0 2px 10px rgba(27,67,50,0.06); font-size: 0.85rem; border-radius: var(--radius); overflow: hidden; }\nth, td { border-bottom: 1px solid var(--line); padding: 0.6rem 0.5rem; vertical-align: top; }\nth { background: var(--forest); color: white; text-align: left; font-size: 0.82rem; }\n.panel { flex: 1 1 320px; background: var(--panel); padding: 1.2rem; border-radius: var(--radius); box-shadow: 0 2px 10px rgba(27,67,50,0.06); border: 1px solid var(--line); }\n.panel h2 { margin-top: 0; font-size: 1rem; color: var(--forest); }\n.panel p.hint { color: var(--ink-soft); font-size: 0.8rem; margin-top: -0.3rem; margin-bottom: 1rem; }\n.form-row { display: flex; gap: 0.9rem; flex-wrap: wrap; margin-bottom: 1rem; }\n.form-row label { display: flex; flex-direction: column; font-size: 0.8rem; color: var(--ink-soft); flex: 1; min-width: 180px; }\n.form-row input, .form-row select, .form-row textarea { padding: 0.5rem; border: 1px solid var(--line); border-radius: var(--radius); margin-top: 0.3rem; font-family: inherit; font-size: 0.88rem; }\nbutton, .btn { background: var(--green); color: white; border: none; padding: 0.6rem 1.2rem; border-radius: var(--radius); cursor: pointer; font-size: 0.9rem; font-weight: 600; text-decoration: none; display: inline-block; }\nbutton:hover, .btn:hover { background: var(--green-hover); }\nbutton.secondary, .btn.secondary { background: transparent; color: var(--ink-soft); border: 1px solid var(--line); }\nbutton.reject { background: var(--red); } button.reject:hover { background: #A2372F; }\n.actions { display: flex; gap: 10px; margin-top: 16px; }\n.modal-overlay { position: fixed; inset: 0; background: rgba(20,38,29,0.55); display: none; align-items: center; justify-content: center; z-index: 1000; padding: 20px; }\n.modal-box { background: var(--panel); border-radius: var(--radius); padding: 26px; max-width: 460px; width: 100%; position: relative; box-shadow: 0 12px 40px rgba(0,0,0,0.25); }\n.modal-close { position: absolute; top: 10px; right: 10px; background: none; border: none; font-size: 1.5rem; cursor: pointer; color: var(--ink-soft); padding: 0; width: 30px; height: 30px; line-height: 1; }\n.modal-box h2 { margin: 0 0 4px; font-size: 1.15rem; color: var(--forest); }\n.stat-label { font-size: 0.75rem; color: var(--ink-soft); text-transform: uppercase; letter-spacing: 0.04em; }\n.stat-value { font-size: 1.35rem; font-weight: 700; margin-top: 2px; }\n.timeline-wrap { max-height: 78vh; }\n.timeline-table { border-collapse: separate; border-spacing: 0; width: max-content; min-width: 100%; }\n.timeline-table th { position: sticky; top: 0; background: var(--panel); color: var(--ink); z-index: 5; padding: 10px 14px; font-size: 0.85rem; border-bottom: 2px solid var(--line); white-space: nowrap; }\n.timeline-table .line-bound-col { position: sticky; left: 0; z-index: 6; background: var(--panel); text-align: left; font-weight: 700; min-width: 110px; border-right: 2px solid var(--line); }\n.bound-tag { font-size: 0.72rem; font-weight: 400; color: var(--ink-soft); }\n.timeline-cell { min-width: 92px; height: 74px; vertical-align: top; padding: 6px; border: 1px solid var(--line); }\n.activity-chip { display: block; width: 100%; box-sizing: border-box; padding: 5px 7px; margin-bottom: 4px; border-radius: 5px; font-size: 0.78rem; font-weight: 700; text-align: center; cursor: pointer; color: #2b2b2b; transition: transform 0.08s; }\n.activity-chip:hover { transform: scale(1.04); }\n.activity-chip.pc-border { border: 3px solid #1B1B1B; }\n.legend-box { display: flex; gap: 36px; flex-wrap: wrap; background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); padding: 16px 20px; margin-top: 20px; }\n.legend-group h4 { margin: 0 0 8px; font-size: 0.82rem; text-transform: uppercase; letter-spacing: 0.04em; color: var(--ink-soft); }\n.legend-group .legend-item { display: flex; align-items: center; gap: 8px; font-size: 0.85rem; margin-bottom: 5px; }\n.legend-swatch { width: 18px; height: 18px; border-radius: 4px; display: inline-block; }\n.legend-swatch.pc-border { border: 3px solid #1B1B1B; }\n.legend-note { font-size: 0.8rem; color: var(--ink-soft); max-width: 260px; line-height: 1.4; }\n.activity-modal { max-width: 620px; max-height: 85vh; overflow-y: auto; }\n.modal-section { margin-top: 18px; padding-top: 14px; border-top: 1px solid var(--line); }\n.modal-section:first-of-type { margin-top: 14px; }\n.modal-section h3 { margin: 0 0 8px; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.04em; color: var(--forest); }\n.kv-grid { display: grid; grid-template-columns: auto 1fr; gap: 4px 14px; font-size: 0.85rem; }\n.kv-grid > div:nth-child(odd) { color: var(--ink-soft); }\n.mini-table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 0.8rem; }\n.mini-table th, .mini-table td { padding: 4px 8px; border-bottom: 1px solid var(--line); text-align: left; }\n.loc-list { margin: 0; padding-left: 18px; font-size: 0.8rem; columns: 2; column-gap: 20px; }\n.sharing-grid { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 8px; }\n.sharing-card { border: 1px solid var(--line); border-radius: 6px; padding: 8px 12px; cursor: pointer; background: #FAFBFA; min-width: 140px; }\n.sharing-card:hover { box-shadow: 0 2px 8px rgba(27,67,50,0.12); }\n.modal-box ul { padding-left: 20px; margin: 8px 0; }\n.network-map { background: #f8fafc; border: 1px solid var(--line); border-radius: var(--radius); padding: 12px; overflow-x: auto; box-shadow: 0 2px 10px rgba(27,67,50,0.08); }\n.network-map svg { display: block; width: 100%; min-width: 900px; max-width: 1365px; height: auto; margin: 0 auto; }\n.scheduler-map-panel { margin-top: 20px; }\n.map-week-controls { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; margin: 14px 0; }\n.map-week-controls input { flex: 1; min-width: 220px; accent-color: var(--green); }\n.map-week-value { min-width: 68px; font-weight: 700; color: var(--forest); }\n.map-access-table { min-width: 560px; margin-top: 10px; box-shadow: none; }\n.map-access-empty { color: var(--ink-soft); font-size: 0.85rem; margin: 10px 0 0; }'


# ============================================================
# SHARED PAGE CHROME + AUTH
# ============================================================

def page_shell(title: str, body_html: str, username: str = None, role: str = None) -> str:
    messages = get_flashed_messages()
    flashed_html = "".join(
        f'<div class="error-banner">{msg}</div>' for msg in messages
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>{CSS}</style>
</head>
<body>
<header class="app-header">
  <div class="brand"><a href="{url_for('ps_index')}">&larr; MRT Maintenance Scheduler</a></div>
  <div class="account">
    Signed in as <strong>{session.get('username')}</strong>
    <span class="role-badge">{session.get('role')}</span>
    <a class="logout" href="{url_for('logout')}">Log out</a>
  </div>
</header>
<div class="app-body">
{flashed_html}
{body_html}
</div>
</body>
</html>"""


PUBLIC_ENDPOINTS = {"login", "register", "static"}


@app.before_request
def require_login():
    endpoint = request.endpoint or ""
    if endpoint in PUBLIC_ENDPOINTS or endpoint.endswith(".static"):
        return None
    if "username" not in session:
        return redirect(url_for("login", next=request.path))
    return None


def supervisor_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if session.get("role") != "supervisor":
            return "Forbidden — supervisors only.", 403
        return view_func(*args, **kwargs)
    return wrapped


LOGIN_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign in — MRT Maintenance Scheduler</title><style>{{ css }}</style></head>
<body>
  <div class="login-wrap">
    <div class="login-box">
      <h1>Sign in</h1>
      <div class="sub">MRT Maintenance Scheduler</div>
      {% if error %}<div class="error">{{ error }}</div>{% endif %}
      <form method="POST">
        <label>Username<input type="text" name="username" required autofocus></label>
        <label>Password<input type="password" name="password" required></label>
        <button type="submit">Sign in</button>
      </form>
      <div class="sub" style="margin-top:16px;">New here? <a href="{{ url_for('register') }}">Create an account</a></div>
    </div>
  </div>
</body>
</html>"""


REGISTER_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register — MRT Maintenance Scheduler</title><style>{{ css }}</style></head>
<body>
  <div class="login-wrap">
    <div class="login-box">
      <h1>Create account</h1>
      <div class="sub">MRT Maintenance Scheduler — Supervisor registration</div>
      {% if error %}<div class="error">{{ error }}</div>{% endif %}
      <form method="POST">
        <label>Full name<input type="text" name="full_name" required autofocus placeholder="e.g. Jamie Koh"></label>
        <label>Username<input type="text" name="username" required placeholder="e.g. jamiekoh"></label>
        <label>Password<input type="password" name="password" required></label>
        <label>Confirm password<input type="password" name="confirm_password" required></label>
        <button type="submit">Register</button>
      </form>
      <div class="sub" style="margin-top:16px;">Already have an account? <a href="{{ url_for('login') }}">Sign in</a></div>
    </div>
  </div>
</body>
</html>"""


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = USERS.get(username)
        if user and user["password"] == password:
            session.clear()
            session["username"] = username
            session["role"] = user["role"]
            return redirect(request.args.get("next") or url_for("home"))
        error = "Invalid username or password."
    return render_template_string(LOGIN_TEMPLATE, error=error, css=CSS)


@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not full_name or not username or not password:
            error = "Full name, username and password are all required."
        elif password != confirm_password:
            error = "Passwords do not match."
        elif username in USERS:
            error = "That username is already taken."
        else:
            USERS[username] = {"password": password, "role": "supervisor"}
            return redirect(url_for("login"))
    return render_template_string(REGISTER_TEMPLATE, error=error, css=CSS)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


HOME_MAP_ONLY_TEMPLATE = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 680" role="img" aria-label="Week 22 operational schedule and reasoning map with Alpha and Beta lines and interchange links">
    <rect width="1600" height="680" fill="#ffffff"/>
    <g fill="#202020" font-size="15" text-anchor="middle"><text x="143" y="137">S01</text><text x="275" y="137">S02</text><text x="405" y="137">S03</text><text x="537" y="137">S04</text><text x="668" y="137">H01</text><text x="799" y="137">H02</text><text x="931" y="137">S05</text><text x="1064" y="137">S06</text><text x="1195" y="137">S07</text><text x="1327" y="137">S08</text></g>
    <g fill="#202020" font-size="15" text-anchor="middle"><text x="143" y="630">S11</text><text x="275" y="630">S12</text><text x="405" y="630">S13</text><text x="537" y="630">S14</text><text x="668" y="630">H01</text><text x="799" y="630">H02</text><text x="931" y="630">S15</text><text x="1064" y="630">S16</text><text x="1195" y="630">S17</text><text x="1327" y="630">S18</text></g>
    <text x="42" y="246" fill="#347fb3" font-size="20" font-weight="700">ALPHA</text><text x="42" y="555" fill="#3a9a3c" font-size="20" font-weight="700">BETA</text>
    <g fill="none" stroke-width="5"><path d="M143 214H1382" stroke="#347fb3"/><path d="M143 275H1382" stroke="#347fb3" stroke-dasharray="13 9"/><path d="M143 521H1382" stroke="#3a9a3c"/><path d="M143 582H1382" stroke="#3a9a3c" stroke-dasharray="13 9"/></g>
    <g fill="#555" opacity="0.72" font-family="Arial, sans-serif" font-size="16" font-weight="600"><text x="77" y="211">EB →</text><text x="78" y="282">← WB</text><text x="77" y="518">EB →</text><text x="78" y="589">← WB</text></g>
    <g fill="#fff" stroke="#347fb3" stroke-width="4"><circle cx="143" cy="244" r="11"/><circle cx="275" cy="244" r="11"/><circle cx="405" cy="244" r="11"/><circle cx="537" cy="244" r="11"/><circle cx="931" cy="244" r="11"/><circle cx="1064" cy="244" r="11"/><circle cx="1195" cy="244" r="11"/><circle cx="1327" cy="244" r="11"/></g>
    <g fill="#fff" stroke="#3a9a3c" stroke-width="4"><circle cx="143" cy="552" r="11"/><circle cx="275" cy="552" r="11"/><circle cx="405" cy="552" r="11"/><circle cx="537" cy="552" r="11"/><circle cx="931" cy="552" r="11"/><circle cx="1064" cy="552" r="11"/><circle cx="1195" cy="552" r="11"/><circle cx="1327" cy="552" r="11"/></g>
    <g fill="#fff" stroke="#111" stroke-width="3"><circle cx="668" cy="244" r="14"/><circle cx="799" cy="244" r="14"/><circle cx="668" cy="552" r="14"/><circle cx="799" cy="552" r="14"/></g>
    <g stroke="#a9a9a9" stroke-width="3"><path d="M668 258V538"/><path d="M799 258V538"/></g>
</svg>
"""


HOME_BODY_TEMPLATE = """
<div class="panel scheduler-map-panel" style="margin-bottom:24px;">
  <h2>Line Access Map</h2>
  <div class="network-map">{{ map_svg|safe }}</div>
</div>
<div class="panel">
  <h2>Railway Access Scheduler</h2>
  <p class="hint">Upload a PS1 problem set, validate it, and run Scenario A, B, or C.</p>
  <a href="{{ url_for('ps_index') }}" class="btn">Open Scheduler</a>
</div>
"""


@app.route("/")
def home():
    body = render_template_string(
        HOME_BODY_TEMPLATE,
        role=session.get("role"),
        map_svg=render_template_string(HOME_MAP_ONLY_TEMPLATE),
    )
    return page_shell(
        "MRT Maintenance Scheduler",
        body,
        session.get("username"),
        session.get("role"),
    )


# ============================================================
# COMPETITION MAP
# ============================================================

NETWORK_MAP_TEMPLATE = """
<div class="topbar">
    <div><h1>Line Access Map</h1>
        <p class="subtitle">AI-generated overview of the Alpha and Beta lines and their H01/H02 interchanges.</p>
    </div>
    <a href="{{ url_for('home') }}" class="btn secondary">Back Home</a>
</div>
<div class="network-map">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 680" role="img" aria-label="Week 22 operational schedule and reasoning map with Alpha and Beta lines and interchange links">
        <rect width="1600" height="680" fill="#ffffff"/>
        <g fill="#202020" font-size="15" text-anchor="middle"><text x="143" y="137">S01</text><text x="275" y="137">S02</text><text x="405" y="137">S03</text><text x="537" y="137">S04</text><text x="668" y="137">H01</text><text x="799" y="137">H02</text><text x="931" y="137">S05</text><text x="1064" y="137">S06</text><text x="1195" y="137">S07</text><text x="1327" y="137">S08</text></g>
        <g fill="#202020" font-size="15" text-anchor="middle"><text x="143" y="630">S11</text><text x="275" y="630">S12</text><text x="405" y="630">S13</text><text x="537" y="630">S14</text><text x="668" y="630">H01</text><text x="799" y="630">H02</text><text x="931" y="630">S15</text><text x="1064" y="630">S16</text><text x="1195" y="630">S17</text><text x="1327" y="630">S18</text></g>
        <text x="42" y="246" fill="#347fb3" font-size="20" font-weight="700">ALPHA</text><text x="42" y="555" fill="#3a9a3c" font-size="20" font-weight="700">BETA</text>
        <g fill="none" stroke-width="5"><path d="M143 214H1382" stroke="#347fb3"/><path d="M143 275H1382" stroke="#347fb3" stroke-dasharray="13 9"/><path d="M143 521H1382" stroke="#3a9a3c"/><path d="M143 582H1382" stroke="#3a9a3c" stroke-dasharray="13 9"/></g>
        <g fill="#555" opacity="0.72" font-family="Arial, sans-serif" font-size="16" font-weight="600"><text x="77" y="211">EB →</text><text x="78" y="282">← WB</text><text x="77" y="518">EB →</text><text x="78" y="589">← WB</text></g>
        <g fill="#fff" stroke="#347fb3" stroke-width="4"><circle cx="143" cy="244" r="11"/><circle cx="275" cy="244" r="11"/><circle cx="405" cy="244" r="11"/><circle cx="537" cy="244" r="11"/><circle cx="931" cy="244" r="11"/><circle cx="1064" cy="244" r="11"/><circle cx="1195" cy="244" r="11"/><circle cx="1327" cy="244" r="11"/></g>
        <g fill="#fff" stroke="#3a9a3c" stroke-width="4"><circle cx="143" cy="552" r="11"/><circle cx="275" cy="552" r="11"/><circle cx="405" cy="552" r="11"/><circle cx="537" cy="552" r="11"/><circle cx="931" cy="552" r="11"/><circle cx="1064" cy="552" r="11"/><circle cx="1195" cy="552" r="11"/><circle cx="1327" cy="552" r="11"/></g>
        <g fill="#fff" stroke="#111" stroke-width="3"><circle cx="668" cy="244" r="14"/><circle cx="799" cy="244" r="14"/><circle cx="668" cy="552" r="14"/><circle cx="799" cy="552" r="14"/></g>
        <g stroke="#a9a9a9" stroke-width="3"><path d="M668 258V538"/><path d="M799 258V538"/></g>
        <defs>
            <marker id="map-arrow-up" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="0" markerUnits="userSpaceOnUse">
                <path d="M0 8 L4 0 L8 8 Z" fill="#D62828"/>
            </marker>
            <marker id="map-arrow-down" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="180" markerUnits="userSpaceOnUse">
                <path d="M0 8 L4 0 L8 8 Z" fill="#D62828"/>
            </marker>
        </defs>
        {% for closure in map_closures|default([]) %}
        <g class="map-closure" data-map-week="{{ closure.week }}">
            <title>{{ closure.activity_label }} · {{ closure.bound }}</title>
            <text x="{{ closure.arrow_x }}" y="{{ closure.label_y }}" fill="#D62828" font-size="16" font-weight="700" text-anchor="middle">{{ closure.activity_label }}</text>
            <path d="M{{ closure.arrow_x }} {{ closure.arrow_start }} L{{ closure.arrow_x }} {{ closure.arrow_end }}" fill="none" stroke="#D62828" stroke-width="3" {% if closure.bound == 'WB' %}stroke-dasharray="3 4"{% endif %} marker-end="url(#{{ closure.marker }})"/>
        </g>
        {% endfor %}
    </svg>
</div>
"""


@app.route("/network-map")
@supervisor_required
def network_map():
    body = render_template_string(
        NETWORK_MAP_TEMPLATE,
        map_closures=(
            scheduler.comp_build_map_closures(
                scheduler.CURRENT_INSTANCE,
                scheduler.CURRENT_RESULT,
            )
            if scheduler.CURRENT_INSTANCE is not None and scheduler.CURRENT_RESULT is not None
            else []
        ),
    )
    return page_shell(
        "Line Access Map",
        body,
        session.get("username"),
        session.get("role"),
    )


# ============================================================
# COMPETITION SCHEDULER UI
# ============================================================

PS_INDEX_TEMPLATE = '\n<div class="topbar">\n  <div><h1>Railway Access Scheduler</h1><p class="subtitle">Competition Mode: upload a problem set, validate it, then run the scheduler.</p></div>\n  <form method="POST" action="{{ url_for(\'ps_restart\') }}" onsubmit="return confirm(\'Restart with a new dataset? This will erase the uploaded dataset and generated results.\');">\n    <button type="submit" class="danger-btn">Restart with new dataset</button>\n  </form>\n</div>\n\n<div class="panel scheduler-map-panel">\n  <h2>Line Access Map</h2>\n  {{ network_map_html|safe }}\n  {% if map_access_enabled %}\n  <div class="map-week-controls">\n    <label for="map-week-slider"><strong>Week</strong></label>\n    <input id="map-week-slider" type="range" min="1" max="{{ map_week_max }}" value="1" step="1" oninput="filterMapAccess(this.value)">\n    <span id="map-week-value" class="map-week-value">Week 1</span>\n  </div>\n  <div class="table-wrap">\n    <table class="map-access-table" id="map-access-table">\n      <thead><tr><th>Activity ID</th><th>Access Sequence</th><th>Week</th><th>ECLO</th><th>Access Night</th></tr></thead>\n      <tbody>\n      {% for row in map_access_rows %}\n        <tr data-map-week="{{ row.week }}"><td>{{ row.activity_id }}</td><td>{{ row.access_seq }}</td><td>{{ row.week }}</td><td>{{ row.eclo }}</td><td>{{ row.access_night }}</td></tr>\n      {% endfor %}\n      </tbody>\n    </table>\n  </div>\n  <p id="map-access-empty" class="map-access-empty">No access rows are scheduled for the selected week.</p>\n  <script>\n    function filterMapAccess(week) {\n      const selectedWeek = Number(week);\n      document.getElementById(\'map-week-value\').textContent = \'Week \' + selectedWeek;\n      let visibleRows = 0;\n      document.querySelectorAll(\'#map-access-table tbody tr\').forEach((row) => {\n        const visible = Number(row.dataset.mapWeek) === selectedWeek;\n        row.style.display = visible ? \'\' : \'none\';\n        if (visible) visibleRows += 1;\n      });\n      document.getElementById(\'map-access-empty\').style.display = visibleRows ? \'none\' : \'block\';\n    }\n    filterMapAccess(1);\n  </script>\n  {% endif %}\n</div>\n\n<div class="panel">\n  <h2>Upload Competition Problem Set</h2>\n  <p class="hint">Upload one ZIP containing the 8 required CSV files, or the individual CSVs directly.</p>\n  <form method="POST" action="{{ url_for(\'comp_upload\') }}" enctype="multipart/form-data">\n    <div class="form-row"><label>ZIP or CSV file(s)<input type="file" name="files" multiple accept=".zip,.csv" required></label></div>\n    <button type="submit">Upload</button>\n  </form>\n\n  {% if detected_files %}\n  <h3 style="margin-top:20px; font-size:0.85rem; color:var(--ink-soft); text-transform:uppercase; letter-spacing:0.05em;">Detected files</h3>\n  <ul style="list-style:none; padding:0; margin:8px 0;">\n    {% for canonical, filename, error in detected_files %}\n    <li style="padding:4px 0; font-size:0.9rem;">\n      {% if error %}&#10060; {{ filename }} &mdash; {{ error }}\n      {% elif canonical %}&#9989; {{ filename }} &rarr; {{ canonical }}\n      {% else %}&#9888;&#65039; {{ filename }} &mdash; unrecognized, not used\n      {% endif %}\n    </li>\n    {% endfor %}\n  </ul>\n  <form method="POST" action="{{ url_for(\'comp_validate\') }}"><button type="submit">Validate Problem Set</button></form>\n  {% endif %}\n\n  {% if validation_errors is not none %}\n    {% if validation_errors|length == 0 %}\n      <div class="info-banner" style="margin-top:16px;"><strong>Status: VALID</strong> &mdash; all required files present and consistent.</div>\n    {% else %}\n      <div class="error-banner" style="margin-top:16px;"><strong>Status: INVALID</strong>\n        <ul style="margin:8px 0 0; padding-left:20px;">{% for e in validation_errors %}<li>{{ e }}</li>{% endfor %}</ul>\n      </div>\n    {% endif %}\n  {% endif %}\n</div>\n\n{% if validation_errors is not none and validation_errors|length == 0 %}\n<div class="panel" style="margin-top:20px;">\n  <h2>Scenario &amp; Run</h2>\n  <form method="POST" action="{{ url_for(\'comp_run\') }}">\n    <div class="form-row">\n      <label>Scenario<select name="scenario">\n        <option value="A" {% if current_scenario==\'A\' %}selected{% endif %}>Scenario A &mdash; Strict Supply, Flexible Schedule</option>\n        <option value="B" {% if current_scenario==\'B\' %}selected{% endif %}>Scenario B &mdash; Strict Schedule, Flexible Supply</option>\n        <option value="C" {% if current_scenario==\'C\' %}selected{% endif %}>Scenario C &mdash; Balanced / Elastic Trade-off</option>\n      </select></label>\n    </div>\n    <button type="submit">Run Scheduler</button>\n  </form>\n</div>\n{% endif %}\n\n{% if run_summary %}\n<div class="panel" style="margin-top:20px;">\n  <h2>Scenario {{ run_summary.scenario }} Results</h2>\n  <p>{% if run_summary.feasible %}<strong style="color:var(--green);">&#10003; FEASIBLE</strong>{% else %}<strong style="color:var(--red);">&#10007; {{ run_summary.violations|length }} violation(s)</strong>{% endif %}\n     &middot; {{ run_summary.completed }}/{{ run_summary.total }} activities scheduled &middot; Objective score: {{ run_summary.objective }}</p>\n  <a href="{{ url_for(\'ps_index\') }}" class="btn">View Full Schedule &amp; Results &rarr;</a>\n</div>\n{% endif %}\n\n'

COMPETITION_RESULTS_TEMPLATE = '\n<div class="topbar">\n  <div><h1>Railway Access Scheduler</h1>\n    <p class="subtitle">Scenario {{ scenario }} &middot;\n      {% if feasible %}<strong style="color:var(--green);">&#10003; FEASIBLE</strong>{% else %}<strong style="color:var(--red);">&#10007; NOT FEASIBLE ({{ violations|length }} issue{{ \'s\' if violations|length != 1 else \'\' }})</strong>{% endif %}\n    </p>\n  </div>\n  <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">\n    <form method="POST" action="{{ url_for(\'ps_restart\') }}" onsubmit="return confirm(\'Restart with a new dataset? This will erase the uploaded dataset and generated results.\');"><button type="submit" class="danger-btn">Restart</button></form>\n  </div>\n</div>\n\n<div class="panel scheduler-map-panel">\n  <h2>Line Access Map</h2>\n  <div class="network-map">{{ network_map_html|safe }}</div>\n</div>\n\n<div class="panel">\n  <div class="map-week-controls">\n    <label for="schedule-week-slider"><strong>Week</strong></label>\n    <input id="schedule-week-slider" type="range" min="1" max="{{ weeks|length }}" value="1" step="1" oninput="filterScheduleWeek(this.value)">\n    <span id="schedule-week-value" class="map-week-value">Week 1</span>\n  </div>\n  <h2>Activity ID Access Table</h2>\n  <div class="table-wrap">\n    <table class="map-access-table">\n      <thead><tr><th>Activity ID</th><th>Access Sequence</th><th>Week</th><th>ECLO</th><th>Access Night</th><th>Locations</th></tr></thead>\n      <tbody>\n      {% for row in weekly_access_rows %}\n        <tr data-access-week="{{ row.week }}"><td>{{ row.activity_id }}</td><td>{{ row.access_seq }}</td><td>{{ row.week }}</td><td>{{ row.eclo }}</td><td>{{ row.access_night }}</td><td>{{ row.locations|join(\', \') }}</td></tr>\n      {% endfor %}\n      </tbody>\n    </table>\n  </div>\n</div>\n\n<div class="panel">\n  <div style="display:flex; gap:32px; flex-wrap:wrap;">\n    <div><div class="stat-label">Activities</div><div class="stat-value">{{ completed }} / {{ total }}</div></div>\n    <div><div class="stat-label">Contracts Overrunning</div><div class="stat-value">{{ soft_scores.contracts_overrunning }}</div></div>\n    <div><div class="stat-label">Total Overrun Days</div><div class="stat-value">{{ soft_scores.overrun_days_total }}</div></div>\n    <div><div class="stat-label">Excess Access-Nights</div><div class="stat-value">{{ soft_scores.excess_access_nights_total }}</div></div>\n    <div><div class="stat-label">ECLO Nights</div><div class="stat-value">{{ soft_scores.eclo_nights_total }}</div></div>\n    <div><div class="stat-label">Objective Score</div><div class="stat-value">{{ objective }}</div></div>\n  </div>\n  {% if violations %}\n  <details style="margin-top:14px;"><summary style="cursor:pointer; color:var(--red); font-weight:600; font-size:0.9rem;">{{ violations|length }} issue(s) found &mdash; click to view</summary>\n    <ul style="margin:10px 0 0; padding-left:20px; font-size:0.83rem; max-height:220px; overflow-y:auto;">\n      {% for v in violations[:50] %}<li><strong>{{ v.rule }}</strong>: {{ v.detail }}</li>{% endfor %}\n      {% if violations|length > 50 %}<li>... and {{ violations|length - 50 }} more</li>{% endif %}\n    </ul>\n  </details>\n  {% endif %}\n</div>\n\n<div class="table-wrap timeline-wrap"><table class="timeline-table">\n  <tr><th class="line-bound-col">Line / Bound</th>{% for w in weeks %}<th>W{{ w }}</th>{% endfor %}</tr>\n  {% for line, bound in line_bounds %}\n  <tr>\n    <td class="line-bound-col">{{ \'Alpha\' if line == \'ALP\' else \'Beta\' }}<br><span class="bound-tag">{{ bound }}</span></td>\n    {% for w in weeks %}\n    <td class="timeline-cell">\n      {% for aid in timeline_cells.get((line, bound, w), []) %}\n      <div class="activity-chip{% if activity_details[aid].pc_border %} pc-border{% endif %}" style="background:{{ activity_details[aid].color }};" onclick="document.getElementById(\'act-modal-{{ aid }}\').style.display=\'flex\'">{{ aid }}</div>\n      {% endfor %}\n    </td>\n    {% endfor %}\n  </tr>\n  {% endfor %}\n</table></div>\n\n<script>\n  function filterScheduleWeek(week) {\n    const selectedWeek = String(week);\n    document.getElementById(\'schedule-week-value\').textContent = \'Week \' + selectedWeek;\n    document.querySelectorAll(\'[data-access-week]\').forEach((element) => {\n      element.style.display = element.dataset.accessWeek === selectedWeek ? \'\' : \'none\';\n    });\n    document.querySelectorAll(\'.map-closure\').forEach((element) => {\n      element.style.display = element.dataset.mapWeek === selectedWeek ? \'\' : \'none\';\n    });\n  }\n  filterScheduleWeek(\'1\');\n</script>\n\n<div class="legend-box">\n  <div class="legend-group">\n    <h4>Nature of Work</h4>\n    <div class="legend-item"><span class="legend-swatch" style="background:#F7E9A0;"></span>Non-live (Consist)</div>\n    <div class="legend-item"><span class="legend-swatch" style="background:#AFCFEF;"></span>Non-live (Others)</div>\n    <div class="legend-item"><span class="legend-swatch" style="background:#F3B79C;"></span>Live</div>\n  </div>\n  <div class="legend-group">\n    <h4>Access Type</h4>\n    <div class="legend-item"><span class="legend-swatch pc-border" style="background:#E5E5E5;"></span>PC (bordered)</div>\n    <div class="legend-item"><span class="legend-swatch" style="background:#E5E5E5;"></span>Non-PC (no border)</div>\n  </div>\n  <div class="legend-group">\n    <h4>Using the Timeline</h4>\n    <div class="legend-note">Each chip is one activity for that line/bound/week. Click any chip for full details. Multiple activities in one week stack vertically in the same cell.</div>\n  </div>\n</div>\n\n\n{% if ai_justification %}\n<div class="panel" style="margin-top:20px;">\n  <div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;">\n    <h2 style="margin:0;">Google AI Justification</h2>\n    <form method="POST" action="{{ url_for(\'comp_explain\') }}"><button type="submit" class="secondary">Regenerate</button></form>\n  </div>\n  <div style="margin-top:12px; white-space:pre-wrap; line-height:1.55; font-size:0.88rem; color:var(--ink-soft);">{{ ai_justification }}</div>\n</div>\n{% endif %}\n\n<div class="actions" style="margin-top:24px;">\n  <form method="POST" action="{{ url_for(\'comp_validate_outputs\') }}"><button type="submit" class="secondary">Re-validate Generated CSVs</button></form>\n  <a href="{{ url_for(\'comp_export\', filename=\'SCHEDULE_ACCESS.csv\') }}" class="btn">Download SCHEDULE_ACCESS.csv</a>\n  <a href="{{ url_for(\'comp_export\', filename=\'SCHEDULE_OCCUPANCY.csv\') }}" class="btn">Download SCHEDULE_OCCUPANCY.csv</a>\n  <a href="{{ url_for(\'comp_export\', filename=\'RESULTS.csv\') }}" class="btn">Download RESULTS.csv</a>\n</div>\n\n{% for aid, d in activity_details.items() %}\n<div class="modal-overlay" id="act-modal-{{ aid }}" onclick="if(event.target===this) this.style.display=\'none\'">\n  <div class="modal-box activity-modal">\n    <button class="modal-close" onclick="document.getElementById(\'act-modal-{{ aid }}\').style.display=\'none\'">&times;</button>\n    <h2>{{ d.activity_id }}</h2>\n\n    <div class="modal-section"><h3>Activity Information</h3>\n      <div class="kv-grid">\n        <div>Contract</div><div>{{ d.contract_number }}</div>\n        <div>Start Location</div><div>{{ d.start_location }}</div>\n        <div>End Location</div><div>{{ d.end_location }}</div>\n        <div>Nature of Work</div><div>{{ d.nature }}</div>\n        <div>Access Type</div><div>{{ d.access_type }}</div>\n        <div>Total Accesses Required</div><div>{{ d.total_accesses }}</div>\n        <div>Accesses Delivered</div><div>{{ d.delivered }}</div>\n        <div>Planned Start Date</div><div>{{ d.planned_start_date }}</div>\n        <div>Activity Priority</div><div>{{ d.activity_priority }}</div>\n      </div>\n    </div>\n\n    <div class="modal-section"><h3>Schedule</h3>\n      <div class="kv-grid">\n        <div>Weeks Used</div><div>{{ d.weeks_used|join(\', \') if d.weeks_used else \'&mdash;\' }}</div>\n        <div>Completion Week</div><div>{{ d.completion_week if d.completion_week else \'Not completed\' }}</div>\n      </div>\n      {% if d.accesses %}\n      <table class="mini-table"><tr><th>Seq</th><th>Week</th><th>Access Night</th><th>ECLO</th></tr>\n      {% for a in d.accesses %}<tr><td>{{ a.seq }}</td><td>{{ a.week }}</td><td>{{ a.access_night }}</td><td>{{ \'Yes\' if a.eclo else \'No\' }}</td></tr>{% endfor %}\n      </table>\n      {% endif %}\n    </div>\n\n    <div class="modal-section"><h3>Contract</h3>\n      <div class="kv-grid">\n        <div>Contract Priority</div><div>{{ d.contract_priority }}</div>\n        <div>Planned Completion Date</div><div>{{ d.planned_completion_date }}</div>\n        <div>Contract Completion Date (hard)</div><div>{{ d.contract_completion_date }}</div>\n        <div>Max Access-Nights / Week</div><div>{{ d.max_access_per_week }}</div>\n        <div>Number of Workfronts</div><div>{{ d.num_workfronts }}</div>\n      </div>\n    </div>\n\n    <div class="modal-section"><h3>Locations</h3>\n      <ul class="loc-list">{% for l in d.locations %}<li>{{ l }}</li>{% endfor %}</ul>\n    </div>\n\n    <div class="modal-section"><h3>Safety / Sharing</h3>\n      <div class="kv-grid">\n        <div>Live Work</div><div>{{ \'Yes\' if d.is_live else \'No\' }}</div>\n        <div>Buffer Sectors</div><div>{{ d.buffer_sectors }}</div>\n        <div>Opposite-Bound Mirrored</div><div>{{ \'Yes\' if d.opposite_bound_mirrored else \'No\' }}</div>\n        <div>Interchange Impact</div><div>{{ \'Yes\' if d.touches_interchange else \'No\' }}</div>\n      </div>\n      {% if d.sharing_with %}\n      <div style="margin-top:10px; font-size:0.82rem; color:var(--ink-soft);">Sharing this possession with:</div>\n      <div class="sharing-grid">\n        {% for partner_id in d.sharing_with %}\n        <div class="sharing-card" onclick="document.getElementById(\'act-modal-{{ aid }}\').style.display=\'none\'; document.getElementById(\'act-modal-{{ partner_id }}\').style.display=\'flex\';">\n          <div style="font-weight:700;">{{ partner_id }}</div>\n          <div style="font-size:0.76rem; color:var(--ink-soft);">{{ activity_details[partner_id].nature }} &middot; {{ activity_details[partner_id].access_type }} &middot; {{ activity_details[partner_id].contract_number }}</div>\n        </div>\n        {% endfor %}\n      </div>\n      {% else %}\n      <div style="margin-top:10px; font-size:0.82rem; color:var(--ink-soft);">Exclusive possession &mdash; not sharing with any other activity.</div>\n      {% endif %}\n    </div>\n\n    <div class="modal-section"><h3>Result</h3>\n      <div class="kv-grid">\n        <div>Scenario</div><div>{{ scenario }}</div>\n        <div>Fully Completed</div><div>{{ \'Yes\' if d.fully_completed else \'No (shortfall: \' ~ d.shortfall ~ \')\' }}</div>\n        <div>Contract Overrun</div><div>{{ (d.contract_overrun_days|string ~ \' day(s)\') if d.contract_overrun_days else \'0 days (on time)\' }}</div>\n      </div>\n    </div>\n  </div>\n</div>\n{% endfor %}\n'


@app.route("/problem-statement/")
@supervisor_required
def ps_index():
    if scheduler.CURRENT_RESULT is not None:
        result = scheduler.CURRENT_RESULT
        line_bounds, timeline_cells = scheduler.comp_get_timeline(result)

        params = dict(zip(
            scheduler.CURRENT_INSTANCE["PARAMETERS"]["key"],
            scheduler.CURRENT_INSTANCE["PARAMETERS"]["value"],
        ))
        try:
            horizon_weeks = max(1, int(params.get("horizon_weeks", 1)))
        except (TypeError, ValueError):
            horizon_weeks = 1

        activity_details = scheduler.comp_build_activity_details(
            scheduler.CURRENT_INSTANCE,
            result,
            scheduler.CURRENT_RESULTS_ROWS,
            scheduler.CURRENT_SCENARIO,
        )
        map_closures = scheduler.comp_build_map_closures(
            scheduler.CURRENT_INSTANCE,
            result,
        )

        body = render_template_string(
            COMPETITION_RESULTS_TEMPLATE,
            scenario=scheduler.CURRENT_SCENARIO,
            feasible=len(scheduler.CURRENT_VIOLATIONS or []) == 0,
            violations=scheduler.CURRENT_VIOLATIONS or [],
            completed=result["completed_count"],
            total=len(result["acts"]),
            soft_scores=scheduler.CURRENT_SOFT_SCORES,
            objective=scheduler.CURRENT_OBJECTIVE_SCORE,
            weeks=list(range(1, horizon_weeks + 1)),
            line_bounds=line_bounds,
            timeline_cells=timeline_cells,
            activity_details=activity_details,
            network_map_html=render_template_string(
                NETWORK_MAP_TEMPLATE,
                map_closures=map_closures,
            ),
            weekly_access_rows=scheduler.comp_get_weekly_access_rows(result),
            ai_justification=CURRENT_AI_JUSTIFICATION,
        )
        return page_shell("Railway Access Scheduler", body)

    map_week_max = 1
    if scheduler.CURRENT_INSTANCE is not None and "PARAMETERS" in scheduler.CURRENT_INSTANCE:
        try:
            params = dict(zip(
                scheduler.CURRENT_INSTANCE["PARAMETERS"]["key"],
                scheduler.CURRENT_INSTANCE["PARAMETERS"]["value"],
            ))
            map_week_max = max(1, int(params.get("horizon_weeks", 1)))
        except (TypeError, ValueError):
            map_week_max = 1

    network_map_html = render_template_string(
        NETWORK_MAP_TEMPLATE,
        map_closures=[],
    )

    body = render_template_string(
        PS_INDEX_TEMPLATE,
        detected_files=scheduler.CURRENT_DETECTED_FILES,
        validation_errors=scheduler.CURRENT_VALIDATION_ERRORS,
        current_scenario=scheduler.CURRENT_SCENARIO,
        run_summary=None,
        network_map_html=network_map_html,
        map_access_rows=scheduler.CURRENT_MAP_ACCESS_ROWS,
        map_access_enabled=scheduler.CURRENT_INSTANCE is not None,
        map_week_max=map_week_max,
        ai_justification=CURRENT_AI_JUSTIFICATION,
    )
    return page_shell("Railway Access Scheduler", body)


@app.route("/problem-statement/competition/upload", methods=["POST"])
@supervisor_required
def comp_upload():
    scheduler.comp_reset_instance()
    uploaded = request.files.getlist("files")

    if not uploaded:
        flash("No files selected.")
        return redirect(url_for("ps_index"))

    file_storages = []
    for fs in uploaded:
        if not fs.filename:
            continue
        if fs.filename.lower().endswith(".zip"):
            file_storages.extend(scheduler.comp_extract_zip(fs))
        else:
            file_storages.append(fs)

    instance, detected = scheduler.comp_parse_uploaded_files(file_storages)
    scheduler.CURRENT_INSTANCE = instance
    scheduler.CURRENT_DETECTED_FILES = detected
    scheduler.CURRENT_VALIDATION_ERRORS = None

    global CURRENT_AI_JUSTIFICATION, CURRENT_VALIDATION_REPORT
    CURRENT_AI_JUSTIFICATION = None
    CURRENT_VALIDATION_REPORT = None

    return redirect(url_for("ps_index"))


@app.route("/problem-statement/restart", methods=["POST"])
@supervisor_required
def ps_restart():
    global CURRENT_AI_JUSTIFICATION, CURRENT_VALIDATION_REPORT
    scheduler.comp_reset_instance()
    CURRENT_AI_JUSTIFICATION = None
    CURRENT_VALIDATION_REPORT = None
    flash("The current dataset and generated results were cleared.")
    return redirect(url_for("ps_index"))


@app.route("/problem-statement/competition/validate", methods=["POST"])
@supervisor_required
def comp_validate():
    if scheduler.CURRENT_INSTANCE is None:
        flash("Upload a problem set first.")
        return redirect(url_for("ps_index"))

    scheduler.CURRENT_VALIDATION_ERRORS = scheduler.comp_validate_instance(
        scheduler.CURRENT_INSTANCE
    )
    return redirect(url_for("ps_index"))


def generate_ai_justification(validation_report):
    """Use Gemini only to explain an already-determined validator report."""
    if not validation_report:
        return "No validator report is available yet."

    violations = validation_report.get("hard_violations", [])
    payload = {
        "scenario": validation_report.get("scenario"),
        "feasible": validation_report.get("feasible"),
        "hard_violation_count": len(violations),
        "hard_violations": violations[:80],
        "soft_scores": validation_report.get("soft_scores", {}),
        "detail": validation_report.get("detail", {}),
    }

    prompt = f"""Explain this railway track-access validator report to a works controller.
The deterministic validator is authoritative. Do not invent rules, change the feasibility
decision, or make scheduling decisions. Explain the status, important violations or
successful checks, affected activities/locations/weeks when available, and the main score
metrics. Keep it concise.

VALIDATOR REPORT:
{json.dumps(payload, indent=2, default=str)}"""

    if genai is None or google is None:
        return _deterministic_ai_fallback(validation_report)

    try:
        project = os.environ.get("GOOGLE_CLOUD_PROJECT")
        if project:
            location = os.environ.get("GOOGLE_CLOUD_LOCATION", "global")
            model = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
            client = genai.Client(
                vertexai=True,
                project=project,
                location=location,
            )
        else:
            # Cloud Shell / local ADC fallback: use the currently authenticated
            # Google Cloud project.
            _, project = google.auth.default()
            location = os.environ.get("GOOGLE_CLOUD_LOCATION", "global")
            model = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
            client = genai.Client(
                vertexai=True,
                project=project,
                location=location,
            )

        response = client.models.generate_content(
            model=model,
            contents=prompt,
        )
        text = (response.text or "").strip()
        return text or _deterministic_ai_fallback(validation_report)
    except Exception as exc:
        return (
            _deterministic_ai_fallback(validation_report)
            + f"\n\nGoogle AI service note: {exc}"
        )


def _deterministic_ai_fallback(report):
    feasible = bool(report.get("feasible"))
    lines = [f"{'FEASIBLE' if feasible else 'NOT FEASIBLE'} — Scenario {report.get('scenario', 'A')}"]
    violations = report.get("hard_violations", [])
    if violations:
        lines.append(f"The validator found {len(violations)} hard violation(s):")
        for violation in violations[:6]:
            lines.append(
                f"- {violation.get('rule', 'rule')}: {violation.get('detail', '')}"
            )
    else:
        lines.append("The submitted three CSV files passed the deterministic hard-rule checks.")

    soft = report.get("soft_scores", {})
    lines.append(f"- Overrun days: {soft.get('overrun_days_total', 0)}")
    lines.append(f"- Excess access-nights: {soft.get('excess_access_nights_total', 0)}")
    lines.append(f"- ECLO nights: {soft.get('eclo_nights_total', 0)}")
    lines.append(f"- Priority-weighted score: {soft.get('priority_weighted_score', 0)}")
    return "\n".join(lines)


@app.route("/problem-statement/competition/run", methods=["POST"])
@supervisor_required
def comp_run():
    global CURRENT_AI_JUSTIFICATION, CURRENT_VALIDATION_REPORT

    if (
        scheduler.CURRENT_INSTANCE is None
        or scheduler.CURRENT_VALIDATION_ERRORS is None
        or len(scheduler.CURRENT_VALIDATION_ERRORS) > 0
    ):
        flash("Upload and validate a problem set before running the scheduler.")
        return redirect(url_for("ps_index"))

    scenario = request.form.get("scenario", "A")
    if scenario not in ("A", "B", "C"):
        scenario = "A"
    scheduler.CURRENT_SCENARIO = scenario

    result = scheduler.comp_run_scenario(
        scheduler.CURRENT_INSTANCE,
        scenario,
    )
    rows, _solver_soft_scores, _solver_objective = scheduler.comp_compute_results(
        result,
        scenario,
    )

    # Write exact PS1 submission CSVs first.
    output_dir = os.path.join(
        scheduler.COMPETITION_OUTPUT_DIR,
        f"scenario_{scenario}",
    )
    output_paths = scheduler.comp_write_outputs(result, rows, output_dir)

    # Then re-read those files and validate the actual files.
    validation_report = scheduler.comp_validate_submission(
        scheduler.CURRENT_INSTANCE,
        output_paths[0],
        output_paths[1],
        output_paths[2],
        scenario,
    )

    scheduler.CURRENT_RESULT = result
    scheduler.CURRENT_RESULTS_ROWS = rows
    scheduler.CURRENT_SOFT_SCORES = validation_report["soft_scores"]
    scheduler.CURRENT_OBJECTIVE_SCORE = validation_report.get("objective_score", 0.0)
    scheduler.CURRENT_VIOLATIONS = validation_report["hard_violations"]
    scheduler.CURRENT_OUTPUT_PATHS = output_paths
    scheduler.CURRENT_MAP_ACCESS_ROWS = result.get("schedule_access_rows", [])

    CURRENT_VALIDATION_REPORT = validation_report
    CURRENT_AI_JUSTIFICATION = generate_ai_justification(validation_report)

    return redirect(url_for("ps_index"))


@app.route("/problem-statement/competition/explain", methods=["POST"])
@supervisor_required
def comp_explain():
    global CURRENT_AI_JUSTIFICATION

    if CURRENT_VALIDATION_REPORT is None:
        flash("Run the scheduler and validator first.")
        return redirect(url_for("ps_index"))

    CURRENT_AI_JUSTIFICATION = generate_ai_justification(
        CURRENT_VALIDATION_REPORT
    )
    return redirect(url_for("ps_index"))


@app.route("/problem-statement/competition/validate-outputs", methods=["POST"])
@supervisor_required
def comp_validate_outputs():
    global CURRENT_AI_JUSTIFICATION, CURRENT_VALIDATION_REPORT

    if scheduler.CURRENT_INSTANCE is None or not scheduler.CURRENT_OUTPUT_PATHS:
        flash("Run the scheduler first so the three submission CSVs exist.")
        return redirect(url_for("ps_index"))

    access_path, occupancy_path, results_path = scheduler.CURRENT_OUTPUT_PATHS
    report = scheduler.comp_validate_submission(
        scheduler.CURRENT_INSTANCE,
        access_path,
        occupancy_path,
        results_path,
        scheduler.CURRENT_SCENARIO,
    )

    CURRENT_VALIDATION_REPORT = report
    scheduler.CURRENT_SOFT_SCORES = report["soft_scores"]
    scheduler.CURRENT_OBJECTIVE_SCORE = report.get("objective_score", 0.0)
    scheduler.CURRENT_VIOLATIONS = report["hard_violations"]
    CURRENT_AI_JUSTIFICATION = generate_ai_justification(report)

    return redirect(url_for("ps_index"))


@app.route("/problem-statement/competition/export/<filename>")
@supervisor_required
def comp_export(filename):
    if scheduler.CURRENT_OUTPUT_PATHS is None:
        flash("Run the scheduler first.")
        return redirect(url_for("ps_index"))

    path_map = {
        "SCHEDULE_ACCESS.csv": scheduler.CURRENT_OUTPUT_PATHS[0],
        "SCHEDULE_OCCUPANCY.csv": scheduler.CURRENT_OUTPUT_PATHS[1],
        "RESULTS.csv": scheduler.CURRENT_OUTPUT_PATHS[2],
    }
    if filename not in path_map:
        return "Unknown file.", 404

    return send_file(
        path_map[filename],
        as_attachment=True,
        download_name=filename,
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    app.run(host="0.0.0.0", port=port)
